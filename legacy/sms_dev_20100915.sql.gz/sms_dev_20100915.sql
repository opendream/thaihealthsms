--
-- PostgreSQL database dump
--

SET statement_timeout = 0;
SET client_encoding = 'SQL_ASCII';
SET standard_conforming_strings = off;
SET check_function_bodies = false;
SET client_min_messages = warning;
SET escape_string_warning = off;

SET search_path = public, pg_catalog;


--
-- Name: accounts_permissionname_id_seq; Type: SEQUENCE SET; Schema: public; Owner: sms_dev
--

SELECT pg_catalog.setval('accounts_permissionname_id_seq', 1, false);


--
-- Name: accounts_roledetails_id_seq; Type: SEQUENCE SET; Schema: public; Owner: sms_dev
--

SELECT pg_catalog.setval('accounts_roledetails_id_seq', 8, true);


--
-- Name: accounts_useraccount_id_seq; Type: SEQUENCE SET; Schema: public; Owner: sms_dev
--

SELECT pg_catalog.setval('accounts_useraccount_id_seq', 28, false);


--
-- Name: accounts_userroleresponsibility_id_seq; Type: SEQUENCE SET; Schema: public; Owner: sms_dev
--

SELECT pg_catalog.setval('accounts_userroleresponsibility_id_seq', 42, false);


--
-- Name: accounts_userroleresponsibility_programs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: sms_dev
--

SELECT pg_catalog.setval('accounts_userroleresponsibility_programs_id_seq', 24, false);


--
-- Name: accounts_userroleresponsibility_sectors_id_seq; Type: SEQUENCE SET; Schema: public; Owner: sms_dev
--

SELECT pg_catalog.setval('accounts_userroleresponsibility_sectors_id_seq', 26, false);


--
-- Name: auth_group_permissions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: sms_dev
--

SELECT pg_catalog.setval('auth_group_permissions_id_seq', 1, false);


--
-- Name: auth_message_id_seq; Type: SEQUENCE SET; Schema: public; Owner: sms_dev
--

SELECT pg_catalog.setval('auth_message_id_seq', 1, false);


--
-- Name: auth_user_groups_id_seq; Type: SEQUENCE SET; Schema: public; Owner: sms_dev
--

SELECT pg_catalog.setval('auth_user_groups_id_seq', 41, false);


--
-- Name: auth_user_id_seq; Type: SEQUENCE SET; Schema: public; Owner: sms_dev
--

SELECT pg_catalog.setval('auth_user_id_seq', 30, false);


--
-- Name: auth_user_user_permissions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: sms_dev
--

SELECT pg_catalog.setval('auth_user_user_permissions_id_seq', 1, false);


--
-- Name: budget_budgetschedule_id_seq; Type: SEQUENCE SET; Schema: public; Owner: sms_dev
--

SELECT pg_catalog.setval('budget_budgetschedule_id_seq', 58, false);


--
-- Name: budget_budgetschedulereference_id_seq; Type: SEQUENCE SET; Schema: public; Owner: sms_dev
--

SELECT pg_catalog.setval('budget_budgetschedulereference_id_seq', 1, false);


--
-- Name: budget_budgetschedulerevision_id_seq; Type: SEQUENCE SET; Schema: public; Owner: sms_dev
--

SELECT pg_catalog.setval('budget_budgetschedulerevision_id_seq', 1, false);


--
-- Name: comment_comment_id_seq; Type: SEQUENCE SET; Schema: public; Owner: sms_dev
--

SELECT pg_catalog.setval('comment_comment_id_seq', 1, false);


--
-- Name: comment_commentreply_id_seq; Type: SEQUENCE SET; Schema: public; Owner: sms_dev
--

SELECT pg_catalog.setval('comment_commentreply_id_seq', 1, false);


--
-- Name: comment_unreadcomment_id_seq; Type: SEQUENCE SET; Schema: public; Owner: sms_dev
--

SELECT pg_catalog.setval('comment_unreadcomment_id_seq', 1, false);


--
-- Name: comment_unreadcommentreply_id_seq; Type: SEQUENCE SET; Schema: public; Owner: sms_dev
--

SELECT pg_catalog.setval('comment_unreadcommentreply_id_seq', 1, false);


--
-- Name: django_admin_log_id_seq; Type: SEQUENCE SET; Schema: public; Owner: sms_dev
--

SELECT pg_catalog.setval('django_admin_log_id_seq', 1, false);


--
-- Name: django_content_type_id_seq; Type: SEQUENCE SET; Schema: public; Owner: sms_dev
--

SELECT pg_catalog.setval('django_content_type_id_seq', 42, true);


--
-- Name: domain_activity_id_seq; Type: SEQUENCE SET; Schema: public; Owner: sms_dev
--

SELECT pg_catalog.setval('domain_activity_id_seq', 8, false);


--
-- Name: domain_plan_id_seq; Type: SEQUENCE SET; Schema: public; Owner: sms_dev
--

SELECT pg_catalog.setval('domain_plan_id_seq', 11, false);


--
-- Name: domain_program_id_seq; Type: SEQUENCE SET; Schema: public; Owner: sms_dev
--

SELECT pg_catalog.setval('domain_program_id_seq', 62, false);


--
-- Name: domain_project_id_seq; Type: SEQUENCE SET; Schema: public; Owner: sms_dev
--

SELECT pg_catalog.setval('domain_project_id_seq', 14, false);


--
-- Name: kpi_domainkpi_id_seq; Type: SEQUENCE SET; Schema: public; Owner: sms_dev
--

SELECT pg_catalog.setval('kpi_domainkpi_id_seq', 17, false);


--
-- Name: kpi_domainkpicategory_id_seq; Type: SEQUENCE SET; Schema: public; Owner: sms_dev
--

SELECT pg_catalog.setval('kpi_domainkpicategory_id_seq', 6, false);


--
-- Name: kpi_domainkpischedule_id_seq; Type: SEQUENCE SET; Schema: public; Owner: sms_dev
--

SELECT pg_catalog.setval('kpi_domainkpischedule_id_seq', 8, false);


--
-- Name: kpi_domainkpischedulereference_id_seq; Type: SEQUENCE SET; Schema: public; Owner: sms_dev
--

SELECT pg_catalog.setval('kpi_domainkpischedulereference_id_seq', 1, false);


--
-- Name: registration_registrationprofile_id_seq; Type: SEQUENCE SET; Schema: public; Owner: sms_dev
--

SELECT pg_catalog.setval('registration_registrationprofile_id_seq', 1, false);


--
-- Name: report_report_id_seq; Type: SEQUENCE SET; Schema: public; Owner: sms_dev
--

SELECT pg_catalog.setval('report_report_id_seq', 8, false);


--
-- Name: report_reportassignment_id_seq; Type: SEQUENCE SET; Schema: public; Owner: sms_dev
--

SELECT pg_catalog.setval('report_reportassignment_id_seq', 11, false);


--
-- Name: report_reportduedates_id_seq; Type: SEQUENCE SET; Schema: public; Owner: sms_dev
--

SELECT pg_catalog.setval('report_reportduedates_id_seq', 1, false);


--
-- Name: report_reportsubmission_id_seq; Type: SEQUENCE SET; Schema: public; Owner: sms_dev
--

SELECT pg_catalog.setval('report_reportsubmission_id_seq', 37, false);


--
-- Name: report_reportsubmissionfileresponse_id_seq; Type: SEQUENCE SET; Schema: public; Owner: sms_dev
--

SELECT pg_catalog.setval('report_reportsubmissionfileresponse_id_seq', 32, false);


--
-- Name: report_reportsubmissionreference_id_seq; Type: SEQUENCE SET; Schema: public; Owner: sms_dev
--

SELECT pg_catalog.setval('report_reportsubmissionreference_id_seq', 1, false);


--
-- Data for Name: auth_user; Type: TABLE DATA; Schema: public; Owner: sms_dev
--

INSERT INTO auth_user VALUES (11, 'wilasinee', '', '', 'wilasinee@thaihealth.or.th', 'sha1$6045f$d83c7156549c4ccee97e04ada55d40b7d158a384', false, true, false, '2010-04-18 13:49:46.174726+07', '2010-04-18 13:49:46.174726+07');
INSERT INTO auth_user VALUES (12, 'ngamjit', '', '', 'ngamjit@thaihealth.or.th', 'sha1$4dda7$f6bf3acdf418e4513d4dbb867fa205547492a74f', false, true, false, '2010-04-18 13:58:45.459236+07', '2010-04-18 13:58:45.459236+07');
INSERT INTO auth_user VALUES (6, 'ben', '', '', 'ben@thaihealth.or.th', 'sha1$85e90$dcde8206fd7d1075272793c7a06ca8a03aa49ee0', false, true, false, '2010-04-18 13:42:54.729512+07', '2010-04-18 13:42:54.729512+07');
INSERT INTO auth_user VALUES (15, 'nuan', '', '', 'nuan@thaihealth.or.th', 'sha1$dee43$1f1c58a7fab877b36efb2d07328decaddfca4841', false, true, false, '2010-04-18 14:05:07.756555+07', '2010-04-18 14:05:07.756555+07');
INSERT INTO auth_user VALUES (17, 'pattama', '', '', 'pattama@thaihealth.or.th', 'sha1$1f5cc$de36f371582dd8b3b0e2e7d147de6ee7127f261f', false, true, false, '2010-04-21 14:30:38.638929+07', '2010-04-21 14:30:38.638929+07');
INSERT INTO auth_user VALUES (18, 'udom', '', '', 'udom@thaihealth.or.th', 'sha1$b5d63$1082c615af4e390cc997f2dfe0ae2d2d407f4cee', false, true, false, '2010-04-21 14:33:13.736147+07', '2010-04-21 14:33:13.736147+07');
INSERT INTO auth_user VALUES (19, 'worawan', '', '', 'worawan@thaihealth.or.th', 'sha1$e0982$562b78634c3e65f222fae9ebf3212456ce9c2639', false, true, false, '2010-04-21 14:34:33.315075+07', '2010-04-21 14:34:33.315075+07');
INSERT INTO auth_user VALUES (25, 'project1', '', '', 'pakchuda@yahoo.com', 'sha1$91638$3d4447032945ea7ce152b5363147f4dacfdc2d25', false, true, false, '2010-06-03 15:14:34.790801+07', '2010-06-03 15:14:05.27502+07');
INSERT INTO auth_user VALUES (16, 'surachet', '', '', 'surachet@thaihealth.or.th', 'sha1$4f1f6$7587bc69960b47cef655033894e5ab6641f5440a', false, true, false, '2010-04-21 14:34:50.409529+07', '2010-04-21 14:28:47.796365+07');
INSERT INTO auth_user VALUES (20, 'sawan', '', '', 'doctornursethailoyalty@yahoo.com', 'sha1$03ca1$1181198212166fe1c4fc576ce97fdfa4c01f7f96', false, true, false, '2010-08-10 14:01:14.577617+07', '2010-04-30 17:15:42.070958+07');
INSERT INTO auth_user VALUES (4, 'pakchuda', '', '', 'pakchuda@thaihealth.or.th', 'sha1$3a557$0e03a5925fcaf85fd317dd3c0eb87be0a8542773', false, true, false, '2010-06-03 15:17:17.973826+07', '2010-03-02 15:41:02.217911+07');
INSERT INTO auth_user VALUES (22, 'praponn', '', '', 'pakchuda@yahoo.com', 'sha1$0f19d$a4a0c0b1373eecd47a871f3952d675f27c46a15b', false, true, false, '2010-04-30 18:39:40.840837+07', '2010-04-30 17:38:45.964194+07');
INSERT INTO auth_user VALUES (29, 'wiwan', '', '', 'wiwan@thaihealth.or.th', 'sha1$6af05$0c180c573dca53fc517f7e799dc135993bda8ecb', false, true, false, '2010-09-09 14:34:37.054676+07', '2010-09-09 14:31:41.673041+07');
INSERT INTO auth_user VALUES (5, 'sec7', '', '', 'klaikong@gmail.com', 'sha1$4bc86$6c981957a6ce00244c032526a30d258c14b7e98f', false, true, false, '2010-05-25 15:15:25.03608+07', '2010-04-08 12:03:58.02611+07');
INSERT INTO auth_user VALUES (3, 'paramate', '', '', 'paramate@changefusion.org', 'sha1$4467a$e5ee3e7a840e80783c7e0a6caa0a3d57d789e5cb', false, true, false, '2010-09-09 23:23:05.272131+07', '2010-03-02 15:34:11.514675+07');
INSERT INTO auth_user VALUES (24, 'project_admin', '', '', 'panuta@gmail.com', 'sha1$0f935$217ba41ada7367a38bbc1120bcfbead2ef75c184', false, true, false, '2010-06-21 14:54:58.736904+07', '2010-05-25 14:13:13.354583+07');
INSERT INTO auth_user VALUES (7, 'supreda', '', '', 'supreda@thaihealth.or.th', 'sha1$9e86a$4a4fce46e735369e9f9cc2895f18c724dcdf3017', false, true, false, '2010-04-18 13:45:20.052016+07', '2010-04-18 13:45:20.052016+07');
INSERT INTO auth_user VALUES (8, 'sirikiat', '', '', 'sirikiat@thaihealth.or.th', 'sha1$67926$4a52559d6b3d8b437a7b85bda63c952fb1b1e09d', false, true, false, '2010-04-18 13:46:33.209583+07', '2010-04-18 13:46:33.209583+07');
INSERT INTO auth_user VALUES (9, 'duangporn', '', '', 'duangporn@thaihealth.or.th', 'sha1$d5ee0$e36e38fdf1e5035cce00683ec94fe2f889ac6248', false, true, false, '2010-04-18 13:47:44.367974+07', '2010-04-18 13:47:44.367974+07');
INSERT INTO auth_user VALUES (10, 'penpan', '', '', 'penpan@thaihealth.or.th', 'sha1$f892a$7de8a5c5ca4bb97ab83df3e33deef19324514751', false, true, false, '2010-04-18 13:48:48.881293+07', '2010-04-18 13:48:48.881293+07');
INSERT INTO auth_user VALUES (28, 'panik', '', '', 'paniksena@gmail.com', 'sha1$9a65e$9133f278ebf44cf42a8160d23a2b598886bf940a', false, true, false, '2010-07-06 17:00:01.50105+07', '2010-07-06 17:00:01.50105+07');
INSERT INTO auth_user VALUES (14, 'supavadee', '', '', 'supavadee@thaihealth.or.th', 'sha1$cdcbc$612880799dc550c5525ec895d0041b9f32eac460', false, true, false, '2010-04-21 11:57:54.336395+07', '2010-04-18 14:04:11.038514+07');
INSERT INTO auth_user VALUES (27, 'test', '', '', 'anubiz138@hotmail.com', 'sha1$489f0$071bb08ff74840745400ce49a9ad5548646c4e91', false, true, false, '2010-07-07 11:29:37.877231+07', '2010-07-06 09:31:51.505495+07');
INSERT INTO auth_user VALUES (26, 'adachi', '', '', 'anubiz138@gmail.com', 'sha1$7dd96$cf7ceb97fa50e62566454869b0a22856a2412967', false, true, false, '2010-07-07 11:39:23.59108+07', '2010-07-05 15:37:45.384784+07');


--
-- Data for Name: accounts_useraccount; Type: TABLE DATA; Schema: public; Owner: sms_dev
--


INSERT INTO accounts_useraccount VALUES (3, 3, 'ปรเมษฐ์', 'พูลสุข', '');
INSERT INTO accounts_useraccount VALUES (4, 4, 'ภัคชุดา', 'วสุวัต', '');
INSERT INTO accounts_useraccount VALUES (5, 5, 'klaikong', 'v', '');
INSERT INTO accounts_useraccount VALUES (6, 6, 'เบญจมาภรณ์ ', 'จันทรพัฒน์', '782117');
INSERT INTO accounts_useraccount VALUES (7, 7, 'สุปรีดา ', 'อดุลยานนท์', '521989');
INSERT INTO accounts_useraccount VALUES (8, 8, 'ศิริเกียรติ ', 'เหลียงกอบกิจ', '132991');
INSERT INTO accounts_useraccount VALUES (9, 9, 'ดวงพร', ' เฮงบุณยพันธ์ ', '195341');
INSERT INTO accounts_useraccount VALUES (10, 10, 'เพ็ญพรรณ ', 'จิตตะเสนีย์', '247750');
INSERT INTO accounts_useraccount VALUES (11, 11, 'วิลาสินี ', 'อดุลยานนท์', '188110');
INSERT INTO accounts_useraccount VALUES (12, 12, 'งามจิตต์ ', 'จันทรสาธิต', '648036');
INSERT INTO accounts_useraccount VALUES (13, 14, 'สุภาวดี ', 'ถิระพานิช', '');
INSERT INTO accounts_useraccount VALUES (14, 15, 'นวลอนันต์ ', 'ตันติเกตุ', '560615');
INSERT INTO accounts_useraccount VALUES (16, 17, 'ปัทมา  ', 'ทุมาวงศ์', '463586');
INSERT INTO accounts_useraccount VALUES (17, 18, 'อุดม', 'วงษ์สิงห์', '355621');
INSERT INTO accounts_useraccount VALUES (18, 19, 'วรวรรณ  ', 'อาภารัตน์', '533695');
INSERT INTO accounts_useraccount VALUES (15, 16, 'สุรเชษฐ ', 'พิทยาพิบูลพงศ์', '');
INSERT INTO accounts_useraccount VALUES (19, 20, 'สวรรค์', 'กาญจนะ', '');
INSERT INTO accounts_useraccount VALUES (22, 24, 'Panu', 'Tangchalermkul', '');
INSERT INTO accounts_useraccount VALUES (23, 25, 'Project', 'Mgn', '');
INSERT INTO accounts_useraccount VALUES (25, 27, 'tester', 'test', '');
INSERT INTO accounts_useraccount VALUES (26, 28, 'ปาณิก ', 'เสนาฤทธิไกร', '130266');
INSERT INTO accounts_useraccount VALUES (24, 26, 'adachi', 'mitsuru', '');
INSERT INTO accounts_useraccount VALUES (21, 22, 'praponn', 'supawanthanangkul', '');
INSERT INTO accounts_useraccount VALUES (27, 29, 'วิวรรณ', 'เอกรินทรากุล', '');


--
-- Data for Name: accounts_userroleresponsibility; Type: TABLE DATA; Schema: public; Owner: sms_dev
--

INSERT INTO accounts_userroleresponsibility VALUES (1, 3, 4);
INSERT INTO accounts_userroleresponsibility VALUES (5, 7, 1);
INSERT INTO accounts_userroleresponsibility VALUES (6, 8, 1);
INSERT INTO accounts_userroleresponsibility VALUES (7, 9, 1);
INSERT INTO accounts_userroleresponsibility VALUES (8, 10, 1);
INSERT INTO accounts_userroleresponsibility VALUES (9, 11, 1);
INSERT INTO accounts_userroleresponsibility VALUES (10, 12, 1);
INSERT INTO accounts_userroleresponsibility VALUES (13, 6, 1);
INSERT INTO accounts_userroleresponsibility VALUES (14, 13, 1);
INSERT INTO accounts_userroleresponsibility VALUES (15, 14, 1);
INSERT INTO accounts_userroleresponsibility VALUES (16, 15, 2);
INSERT INTO accounts_userroleresponsibility VALUES (17, 16, 2);
INSERT INTO accounts_userroleresponsibility VALUES (18, 17, 2);
INSERT INTO accounts_userroleresponsibility VALUES (19, 18, 2);
INSERT INTO accounts_userroleresponsibility VALUES (25, 19, 3);
INSERT INTO accounts_userroleresponsibility VALUES (30, 5, 3);
INSERT INTO accounts_userroleresponsibility VALUES (32, 22, 3);
INSERT INTO accounts_userroleresponsibility VALUES (33, 23, 3);
INSERT INTO accounts_userroleresponsibility VALUES (36, 25, 1);
INSERT INTO accounts_userroleresponsibility VALUES (37, 26, 4);
INSERT INTO accounts_userroleresponsibility VALUES (38, 24, 2);
INSERT INTO accounts_userroleresponsibility VALUES (39, 4, 2);
INSERT INTO accounts_userroleresponsibility VALUES (40, 27, 2);
INSERT INTO accounts_userroleresponsibility VALUES (41, 21, 3);


--
-- Data for Name: domain_plan; Type: TABLE DATA; Schema: public; Owner: sms_dev
--

INSERT INTO domain_plan VALUES (3, 13, '1302', 'กลุ่มแผนงานพัฒนานโยบายและกลไกสาธารณะ', '2010-03-31 13:45:55.111062+07');
INSERT INTO domain_plan VALUES (4, 13, '1303', 'กลุ่มแผนงานสนับสนุนพัฒนากลไกทางสังคม', '2010-03-31 13:46:39.572599+07');
INSERT INTO domain_plan VALUES (5, 13, '1304', 'กลุ่มกลไกพัฒนาสมรรถนะและสนับสนุนบุคลากร', '2010-03-31 13:47:35.085416+07');
INSERT INTO domain_plan VALUES (9, 12, '1203', 'กลุ่มแผนงานสร้างและจัดการความรู้', '2010-04-18 13:03:37.790397+07');
INSERT INTO domain_plan VALUES (10, 12, '1204', 'กลุ่มแผนงานพัฒนาระบบสุขภาพชุมชน ', '2010-04-18 13:04:15.645282+07');
INSERT INTO domain_plan VALUES (6, 13, '1305', 'กลุ่มแผนงานกลไกการสนับสนุนการจัดการขององค์กร', '2010-03-31 13:48:21.35392+07');
INSERT INTO domain_plan VALUES (2, 13, '1301', 'กลุ่มแผนงานกลไกการพัฒนาระบบ และการสร้างองค์ความรู้', '2010-03-02 15:24:11.93537+07');
INSERT INTO domain_plan VALUES (8, 12, '1202', 'กลุ่มแผนงานพัฒนาระบบกลไกการจัดการบริการสร้างเสริมสุขภาพและป้องกันโรคในรูปแบบต่างๆ', '2010-04-18 13:03:06.399224+07');
INSERT INTO domain_plan VALUES (7, 12, '1201', 'กลุ่มแผนงานพัฒนาบุคลากรสุขภาพ', '2010-04-18 13:01:24.883639+07');


--
-- Data for Name: domain_program; Type: TABLE DATA; Schema: public; Owner: sms_dev
--

INSERT INTO domain_program VALUES (5, 2, '51-00920', 'ระบบออนไลน์เพื่อการจัดการความรู้สุขภาวะ', '', '', '', '2008-06-01', '2011-05-31', 0, '2010-04-07 16:31:31.936563+07');
INSERT INTO domain_program VALUES (18, 3, '49-01961', 'แผนงานพัฒนากระบวนการนโยบายสาธารณะเพื่อสุขภาพอย่างมีส่วนร่วมเพื่อการสร้างเสริมสุขภาพ', '', '', '', '2006-10-01', '2011-09-30', 0, '2010-04-18 15:35:34.177286+07');
INSERT INTO domain_program VALUES (2, 2, '51-00293', 'แผนงานเทคโนโลยีสารสนเทศเพื่อการสร้างเสริมสุขภาวะและการสนับสนุนภาคีเครือข่าย', '', '', '', '2008-02-01', '2011-01-31', 0, '2010-03-02 15:25:23.199719+07');
INSERT INTO domain_program VALUES (19, 3, '51-01817', 'แผนงานสร้างเสริมการเรียนรู้กับสถาบันอุดมศึกษาไทยเพื่อการพัฒนานโยบายสาธารณะที่ดี', '', '', '', '2008-11-01', '2009-10-31', 0, '2010-04-18 15:36:08.307851+07');
INSERT INTO domain_program VALUES (22, 3, '52-00368', 'ศึกษาแนวทางการสร้างสุขภาวะในการชุมนุมสาธารณะ', '', '', '', '2009-05-16', '2010-05-15', 0, '2010-04-18 15:37:20.60439+07');
INSERT INTO domain_program VALUES (20, 3, '51-01819', 'พัฒนาการมีส่วนร่วมในการกำหนดนโยบายสาธารณะด้านสิทธิที่เชื่อมโยงกับสุขภาวะ', '', '', '', '2008-10-01', '2010-09-30', 0, '2010-04-18 15:36:31.951192+07');
INSERT INTO domain_program VALUES (23, 3, '52-01053', 'วิจัย "กระบวนการรับฟังความคิดเห็นของภาคประชาชนเพื่อสุขภาวะที่ดีของสังคม"', '', '', '', '2009-08-01', '2010-07-31', 0, '2010-04-18 15:37:41.253435+07');
INSERT INTO domain_program VALUES (24, 3, '52-01054', 'ศึกษาแนวทางการสร้างเสริมสุขภาวะในกระบวนการนิติบัญญัติ', '', '', '', '2009-08-01', '2010-07-31', 0, '2010-04-18 15:38:05.942205+07');
INSERT INTO domain_program VALUES (25, 3, '52-01055', 'ศึกษาวิจัยเรื่องการสร้างกลไกเพื่อส่งเสริมสุขภาวะทางสังคมในการร่วมตัดสินใจของประชาชนในระดับท้องถิ่น', '', '', '', '2009-08-01', '2010-10-31', 0, '2010-04-18 15:38:29.196827+07');
INSERT INTO domain_program VALUES (4, 2, '48-02873', 'แผนงานพัฒนาระบบข้อมูลข่าวสารสุขภาพแห่งชาติ ระยะที่ 2', '', '', '', '2005-10-01', '2010-10-31', 0, '2010-04-07 16:27:20.275486+07');
INSERT INTO domain_program VALUES (7, 2, '52-01735', 'ศึกษาวัคซีนไข้หวัดใหญ่ชนิดเชื้อเป็นแบบอ่อนฤทธิ์สายพันธุ์A/17/CA/2009/38(H1N1)(PLAIV)ระยะที่1/2เพื่อดูความปลอดภัยและภูมิคุ้มกันในผู้ใหญ่ที่มีสุขภาพแข็งแรง', '', '', '', '2009-09-01', '2010-08-31', 0, '2010-04-07 16:34:05.986398+07');
INSERT INTO domain_program VALUES (8, 2, '53-00314', 'บูรณาการเกษตรปลอดสารอาหารปลอดภัยจากสารพิษภาคเหนือตอนล่าง', '', '', '', '2010-04-01', '2011-11-30', 0, '2010-04-07 16:35:38.171209+07');
INSERT INTO domain_program VALUES (12, 2, '46-01589', 'สถาบันวิจัยและพัฒนาสุขภาพภาคใต้', '', '', '', '2003-12-15', '2006-12-31', 0, '2010-04-18 15:28:26.366941+07');
INSERT INTO domain_program VALUES (15, 2, '52-01917', 'สถาบันวิจัยและพัฒนาสุขภาพภาคใต้', '', '', '', '2009-12-01', '2012-11-30', 0, '2010-04-18 15:31:28.91658+07');
INSERT INTO domain_program VALUES (17, 2, '53-00449', 'แผนงานประเมินเทคโนโลยีและนโยบายเพื่อการลงทุนด้านสุขภาพ', '', '', '', '2010-02-17', '2013-02-15', 0, '2010-04-18 15:34:57.582842+07');
INSERT INTO domain_program VALUES (26, 3, '52-01105', 'สร้างเสริมสุขภาพในองค์กรทางนิติบัญญัติ', '', '', '', '2009-06-01', '2010-05-31', 0, '2010-04-18 15:38:56.41108+07');
INSERT INTO domain_program VALUES (27, 3, '52-01435', 'การศึกษาแนวทางช่วยเหลือบุคคลไร้ที่อยู่อาศัย (คนไร้บ้าน) : กรณีการจัดศูนย์พักคนไร้บ้าน', '', '', '', '2009-09-01', '2010-06-30', 0, '2010-04-18 15:39:14.403998+07');
INSERT INTO domain_program VALUES (29, 3, '52-01739', 'ประเมินผลโครงการสถาบันวิจัยและพัฒนาสุขภาพภาคใต้', '', '', '', '2009-09-07', '2009-12-07', 0, '2010-04-18 15:40:08.227703+07');
INSERT INTO domain_program VALUES (16, 8, '53-00072', 'การพัฒนาศักยภาพการเฝ้าระวังด้านระบาดวิทยาและภาคีการควบคุมโรคไข้หวัดใหญ่ระดับจังหวัด', '', '', '', '2009-11-02', '2010-10-31', 0, '2010-04-18 15:33:57.958287+07');
INSERT INTO domain_program VALUES (9, 2, '53-00327', 'การศึกษาการระบาดของไข้หวัดใหญ่สายพันธ์ใหม่ 2009 ที่อำเภอทุ่งสง  นครศรีธรรมราช', '', '', '', '2010-01-15', '2011-01-14', 0, '2010-04-07 16:37:02.520161+07');
INSERT INTO domain_program VALUES (32, 4, '52-00106', 'เครือข่ายร่วมพัฒนาศักยภาพผู้นำการสร้างสุขภาวะแนวใหม่ (คศน.)', '', '', '', '2009-01-15', '2011-12-30', 0, '2010-04-18 15:41:36.798078+07');
INSERT INTO domain_program VALUES (33, 4, '52-00716', 'แผนงานวิจัยและพัฒนาฐานข้อมูลเพื่อการตรวจสอบทางสังคม', '', '', '', '2009-04-20', '2012-05-19', 0, '2010-04-18 15:42:07.624357+07');
INSERT INTO domain_program VALUES (42, 7, '53-00061', 'โรงเรียนแพทย์สร้างเสริมสุขภาพ (ปีที่ 2-3)', '', '', '', '2010-01-01', '2011-12-31', 0, '2010-04-21 11:19:51.338604+07');
INSERT INTO domain_program VALUES (35, 4, '52-01050', 'พัฒนางานวิชาการเสริมสร้างสังคมสุขภาวะด้วยการขับเคลื่อนให้ประเทศไทยเป็นสังคมที่มีความเป็นธรรม', '', '', '', '2009-04-16', '2010-04-15', 0, '2010-04-18 15:43:01.393704+07');
INSERT INTO domain_program VALUES (36, 4, '52-01334', 'สร้างเสริมภาคีการพัฒนารัฐ-สังคมเพื่อสุขภาวะประเทศไทย', '', '', '', '2009-07-01', '2010-04-30', 0, '2010-04-18 15:43:23.860727+07');
INSERT INTO domain_program VALUES (37, 4, '52-01383', 'การบริหารจัดการพัฒนางานวิชาการเสริมสร้างงานวิจัยและพัฒนาฐานข้อมูลเพื่อการตรวจสอบทางสังคม', '', '', '', '2009-08-15', '2012-08-15', 0, '2010-04-18 15:43:46.03598+07');
INSERT INTO domain_program VALUES (38, 4, '52-01580', 'การบริหารจัดการ การพัฒนาแผนงานขับเคลื่อนสังคมไทยด้วยดัชนีชี้วัดความก้าวหน้าที่แท้จริง', '', '', '', '2009-08-05', '2009-11-05', 0, '2010-04-18 15:44:10.168029+07');
INSERT INTO domain_program VALUES (39, 4, '53-00274', 'พัฒนาแผนงานระบบยุติธรรมกับสุขภาวะ', '', '', '', '2010-01-18', '2010-07-31', 0, '2010-04-18 15:44:30.226143+07');
INSERT INTO domain_program VALUES (40, 4, '53-00399', 'สร้างเสริมกิจการเพื่อสังคม (Social Enterprise) ด้านสุขภาวะ', '', '', '', '2010-03-01', '2011-03-31', 0, '2010-04-18 15:44:51.334736+07');
INSERT INTO domain_program VALUES (6, 2, '52-01652', 'ศึกษาภูมิคุ้มกันต่อไวรัสไข้หวัดใหญ่สายพันธ์ใหม่ในผู้ป่วยที่มีอาการ และอาสาสมัครที่ไม่มีอาการ : ข้อมูลสำคัญสำหรับการพัฒนาวัคซีนป้องกันโรคไข้หวัดใหญ่', '', '', '', '2009-08-25', '2010-09-25', 0, '2010-04-07 16:32:56.144738+07');
INSERT INTO domain_program VALUES (31, 3, '53-00209', 'แผนงานสร้างเสริมการเรียนรู้กับสถาบันอุดมศึกษาไทย เพื่อการพัฒนานโยบายสาธารณะที่ดี (นสธ.)', '', '', '', '2010-01-04', '2011-01-03', 0, '2010-04-18 15:40:48.847965+07');
INSERT INTO domain_program VALUES (41, 7, '52-00133', 'โรงเรียนแพทย์สร้างเสริมสุขภาพ', '', '', '', '2009-01-05', '2009-12-31', 0, '2010-04-21 11:19:13.203789+07');
INSERT INTO domain_program VALUES (43, 7, '51-00784', 'โรงเรียนทันตแพทย์สร้างสุข', '', '', '', '2008-06-01', '2011-06-30', 0, '2010-04-21 11:21:03.268432+07');
INSERT INTO domain_program VALUES (44, 7, '50-00919', 'แผนงานเครือข่ายเภสัชศาสตร์เพื่อการสร้างเสริมสุขภาพ (คภ.สสส.) ระยะที่ 2 (พ.ศ.2550-2553)', '', '', '', '2007-06-01', '2010-06-30', 0, '2010-04-21 11:24:45.651074+07');
INSERT INTO domain_program VALUES (45, 7, '51-00604', 'แผนงานพัฒนาเครือข่ายพยาบาลศาสตร์เพื่อการสร้างเสริมสุขภาพระยะที่ 2 (2551-2553)', '', '', '', '2008-05-01', '2011-01-15', 0, '2010-04-21 11:26:08.421956+07');
INSERT INTO domain_program VALUES (46, 7, '51-00792', 'พัฒนาสถาบันการศึกษาสาธารณสุขให้เป็นองค์กรสร้างเสริมสุขภาพ', '', '', '', '2008-07-01', '2011-05-31', 0, '2010-04-21 11:27:29.714089+07');
INSERT INTO domain_program VALUES (49, 8, '53-00477', 'พัฒนาด้านการรักษาผู้ป่วยฉุกเฉินระดับวิกฤตภายใต้ข้อจำกัดต่างๆ', '', '', '', '2010-03-01', '2010-03-31', 0, '2010-04-21 11:32:04.70853+07');
INSERT INTO domain_program VALUES (51, 9, '49-01761', 'แผนงานพัฒนาต้นแบบการดำเนินงานสร้างเสริมสุขภาพในบริบทพยาบาล ระยะที่ 2', '', '', '', '2007-01-01', '2009-12-01', 0, '2010-04-21 11:35:00.809267+07');
INSERT INTO domain_program VALUES (52, 9, '51-02155', 'การจัดการความรู้ในการพัฒนาศักยภาพหมออนามัย เพื่อการทำงานด้วยหัวใจแห่งความเป็นมนุษย์', '', '', '', '2008-10-01', '2011-09-30', 0, '2010-04-21 11:36:20.981927+07');
INSERT INTO domain_program VALUES (53, 10, '51-02415', 'พัฒนาระบบสุขภาพชุมชน โดยชุมชน เพื่อชุมชน', '', '', '', '2008-12-16', '2011-12-15', 0, '2010-04-21 11:37:35.986442+07');
INSERT INTO domain_program VALUES (47, 8, '48-02895', 'แผนงานร่วมสร้างเสริมสุขภาพกับระบบหลักประกันสุขภาพถ้วนหน้า ปี 2549 - 2551', '', '', '', '2005-10-01', '2009-10-30', 0, '2010-04-21 11:28:35.322594+07');
INSERT INTO domain_program VALUES (55, 7, '49-01769', 'แผนงานรณรงค์รักษ์สุขภาพโดยแพทย์ร่วมกับสหวิชาชีพ ระยะที่ 2', '', '', '', NULL, NULL, 0, '2010-04-21 13:23:10.807164+07');
INSERT INTO domain_program VALUES (50, 7, '51-02827', 'แผนพัฒนากำลังคนด้านสุขภาพ ระยะที่ 2', '', '', '', '2009-01-01', '2011-12-31', 0, '2010-04-21 11:33:26.206723+07');
INSERT INTO domain_program VALUES (54, 9, '53-00124', 'พัฒนาแผนการดำเนินงานสร้างเสริมสุขภาพของชมรมทันตสาธารณสุขภูธรและชมรมเภสัชชนบท', '', '', '', '2009-12-01', '2010-02-28', 0, '2010-04-21 11:38:32.44129+07');
INSERT INTO domain_program VALUES (48, 10, '52-00492', 'แผนงานการสนับสนุนกลไกการบริหารจัดการเพื่อการพัฒนาระบบบริการปฐมภูมิ"โรงพยาบาลส่งเสริมสุขภาพระดับตำบล"', '', '', '', '2009-08-01', '2012-07-31', 0, '2010-04-21 11:29:40.836096+07');
INSERT INTO domain_program VALUES (57, 10, '52-01506', 'การจัดการความรู้สู่การพัฒนาสถานีอนามัยเป็นโรงพยาบาลส่งเสริมสุขภาพตำบล', '', '', '', NULL, NULL, 0, '2010-04-21 13:32:57.693427+07');
INSERT INTO domain_program VALUES (58, 9, '49-00734', 'แผนงานพัฒนาภูมิปัญญาท้องถิ่นด้านสุขภาพเพื่อการพึ่งพาตนเองของชุมชน', '', '', '', NULL, NULL, 0, '2010-04-21 13:33:49.575544+07');
INSERT INTO domain_program VALUES (59, 9, '51-01083', 'สนับสนุนกระบวนการจัดการความรู้จากงานประจำสู่งานวิจัยอย่างต่อเนื่อง', '', '', '', NULL, NULL, 0, '2010-04-21 13:34:23.069344+07');
INSERT INTO domain_program VALUES (60, 7, '51-01256', 'ติดตามและประเมินผลภายนอกกลุ่มแผนงานพัฒนาบุคลากรสุขภาพปีที่ 4-5', '', '', '', NULL, NULL, 0, '2010-04-21 13:36:14.2261+07');
INSERT INTO domain_program VALUES (61, 7, '52-00834', 'สนับสนุนแผนงานการผลิตพยาบาลชุมชน เพื่อชุมชน ของชุมชนและโดยชุมชน', '', '', '', NULL, NULL, 0, '2010-04-21 13:36:49.995135+07');


--
-- Data for Name: accounts_userroleresponsibility_programs; Type: TABLE DATA; Schema: public; Owner: sms_dev
--

INSERT INTO accounts_userroleresponsibility_programs VALUES (1, 1, 2);
INSERT INTO accounts_userroleresponsibility_programs VALUES (14, 25, 9);
INSERT INTO accounts_userroleresponsibility_programs VALUES (18, 30, 2);
INSERT INTO accounts_userroleresponsibility_programs VALUES (20, 32, 9);
INSERT INTO accounts_userroleresponsibility_programs VALUES (21, 33, 9);
INSERT INTO accounts_userroleresponsibility_programs VALUES (22, 37, 5);
INSERT INTO accounts_userroleresponsibility_programs VALUES (23, 41, 9);


--
-- Data for Name: accounts_userroleresponsibility_sectors; Type: TABLE DATA; Schema: public; Owner: sms_dev
--

INSERT INTO accounts_userroleresponsibility_sectors VALUES (4, 5, 1);
INSERT INTO accounts_userroleresponsibility_sectors VALUES (5, 6, 2);
INSERT INTO accounts_userroleresponsibility_sectors VALUES (6, 7, 3);
INSERT INTO accounts_userroleresponsibility_sectors VALUES (7, 8, 4);
INSERT INTO accounts_userroleresponsibility_sectors VALUES (8, 9, 5);
INSERT INTO accounts_userroleresponsibility_sectors VALUES (9, 10, 6);
INSERT INTO accounts_userroleresponsibility_sectors VALUES (12, 13, 7);
INSERT INTO accounts_userroleresponsibility_sectors VALUES (13, 14, 8);
INSERT INTO accounts_userroleresponsibility_sectors VALUES (14, 15, 9);
INSERT INTO accounts_userroleresponsibility_sectors VALUES (15, 16, 7);
INSERT INTO accounts_userroleresponsibility_sectors VALUES (16, 17, 7);
INSERT INTO accounts_userroleresponsibility_sectors VALUES (17, 18, 7);
INSERT INTO accounts_userroleresponsibility_sectors VALUES (18, 19, 7);
INSERT INTO accounts_userroleresponsibility_sectors VALUES (22, 36, 7);
INSERT INTO accounts_userroleresponsibility_sectors VALUES (23, 38, 7);
INSERT INTO accounts_userroleresponsibility_sectors VALUES (24, 39, 7);
INSERT INTO accounts_userroleresponsibility_sectors VALUES (25, 40, 7);


--
-- Data for Name: django_content_type; Type: TABLE DATA; Schema: public; Owner: sms_dev
--


--
-- Data for Name: auth_group_permissions; Type: TABLE DATA; Schema: public; Owner: sms_dev
--



--
-- Data for Name: auth_message; Type: TABLE DATA; Schema: public; Owner: sms_dev
--



--
-- Data for Name: auth_user_groups; Type: TABLE DATA; Schema: public; Owner: sms_dev
--

INSERT INTO auth_user_groups VALUES (1, 3, 5);
INSERT INTO auth_user_groups VALUES (5, 7, 1);
INSERT INTO auth_user_groups VALUES (6, 8, 1);
INSERT INTO auth_user_groups VALUES (7, 9, 1);
INSERT INTO auth_user_groups VALUES (8, 10, 1);
INSERT INTO auth_user_groups VALUES (9, 11, 1);
INSERT INTO auth_user_groups VALUES (10, 12, 1);
INSERT INTO auth_user_groups VALUES (13, 6, 1);
INSERT INTO auth_user_groups VALUES (14, 14, 1);
INSERT INTO auth_user_groups VALUES (15, 15, 1);
INSERT INTO auth_user_groups VALUES (16, 16, 2);
INSERT INTO auth_user_groups VALUES (17, 17, 2);
INSERT INTO auth_user_groups VALUES (18, 18, 2);
INSERT INTO auth_user_groups VALUES (19, 19, 2);
INSERT INTO auth_user_groups VALUES (25, 20, 4);
INSERT INTO auth_user_groups VALUES (29, 5, 4);
INSERT INTO auth_user_groups VALUES (31, 24, 4);
INSERT INTO auth_user_groups VALUES (32, 25, 4);
INSERT INTO auth_user_groups VALUES (35, 27, 1);
INSERT INTO auth_user_groups VALUES (36, 28, 5);
INSERT INTO auth_user_groups VALUES (37, 26, 2);
INSERT INTO auth_user_groups VALUES (38, 4, 2);
INSERT INTO auth_user_groups VALUES (39, 29, 2);
INSERT INTO auth_user_groups VALUES (40, 22, 4);


--
-- Data for Name: auth_user_user_permissions; Type: TABLE DATA; Schema: public; Owner: sms_dev
--



--
-- Data for Name: budget_budgetschedule; Type: TABLE DATA; Schema: public; Owner: sms_dev
--

INSERT INTO budget_budgetschedule VALUES (11, 4, 22000000, 0, '2010-03-31', NULL, '');
INSERT INTO budget_budgetschedule VALUES (12, 4, 12000000, 0, '2010-09-30', NULL, '');
INSERT INTO budget_budgetschedule VALUES (3, 2, 20000000, 0, '2008-02-01', NULL, '');
INSERT INTO budget_budgetschedule VALUES (4, 2, 15000000, 0, '2008-11-01', NULL, '');
INSERT INTO budget_budgetschedule VALUES (5, 2, 12000000, 0, '2009-04-01', NULL, '');
INSERT INTO budget_budgetschedule VALUES (6, 2, 12000000, 0, '2009-09-01', NULL, '');
INSERT INTO budget_budgetschedule VALUES (7, 2, 10000000, 0, '2010-02-01', NULL, '');
INSERT INTO budget_budgetschedule VALUES (8, 2, 10000000, 0, '2010-07-01', NULL, '');
INSERT INTO budget_budgetschedule VALUES (9, 2, 10500000, 0, '2010-12-01', NULL, '');
INSERT INTO budget_budgetschedule VALUES (10, 2, 500000, 0, '2011-03-01', NULL, '');
INSERT INTO budget_budgetschedule VALUES (13, 5, 3680000, 0, '2010-03-31', NULL, '');
INSERT INTO budget_budgetschedule VALUES (14, 5, 3680000, 0, '2010-09-30', NULL, '');
INSERT INTO budget_budgetschedule VALUES (15, 6, 3500000, 0, '2010-02-28', NULL, '');
INSERT INTO budget_budgetschedule VALUES (16, 6, 2450000, 0, '2010-05-31', NULL, '');
INSERT INTO budget_budgetschedule VALUES (17, 7, 5000000, 0, '2010-02-28', NULL, '');
INSERT INTO budget_budgetschedule VALUES (18, 7, 2100000, 0, '2010-05-31', NULL, '');
INSERT INTO budget_budgetschedule VALUES (19, 7, 60000, 0, '2010-09-30', NULL, '');
INSERT INTO budget_budgetschedule VALUES (20, 38, 10000, 0, '2009-12-31', NULL, '');
INSERT INTO budget_budgetschedule VALUES (21, 37, 400000, 0, '2010-01-31', NULL, '');
INSERT INTO budget_budgetschedule VALUES (22, 37, 400000, 0, '2010-04-30', NULL, '');
INSERT INTO budget_budgetschedule VALUES (23, 37, 400000, 0, '2010-07-31', NULL, '');
INSERT INTO budget_budgetschedule VALUES (24, 33, 4000000, 0, '2009-10-31', NULL, '');
INSERT INTO budget_budgetschedule VALUES (25, 33, 4500000, 0, '2010-04-30', NULL, '');
INSERT INTO budget_budgetschedule VALUES (28, 35, 440000, 0, '2010-02-28', NULL, '');
INSERT INTO budget_budgetschedule VALUES (29, 35, 220000, 0, '2010-04-30', NULL, '');
INSERT INTO budget_budgetschedule VALUES (30, 18, 19000000, 0, '2009-10-31', NULL, '');
INSERT INTO budget_budgetschedule VALUES (31, 18, 11000000, 0, '2010-04-30', NULL, '');
INSERT INTO budget_budgetschedule VALUES (32, 19, 2000000, 0, '2009-12-31', NULL, '');
INSERT INTO budget_budgetschedule VALUES (33, 20, 8500000, 0, '2009-12-31', NULL, '');
INSERT INTO budget_budgetschedule VALUES (34, 20, 11000000, 0, '2010-06-30', NULL, '');
INSERT INTO budget_budgetschedule VALUES (35, 22, 400000, 0, '2009-12-31', NULL, '');
INSERT INTO budget_budgetschedule VALUES (36, 22, 60000, 0, '2010-06-30', NULL, '');
INSERT INTO budget_budgetschedule VALUES (37, 24, 400000, 0, '2010-03-31', NULL, '');
INSERT INTO budget_budgetschedule VALUES (38, 24, 100000, 0, '2010-07-31', NULL, '');
INSERT INTO budget_budgetschedule VALUES (39, 23, 400000, 0, '2010-01-31', NULL, '');
INSERT INTO budget_budgetschedule VALUES (40, 23, 100000, 0, '2010-07-31', NULL, '');
INSERT INTO budget_budgetschedule VALUES (41, 25, 500000, 0, '2010-04-30', NULL, '');
INSERT INTO budget_budgetschedule VALUES (42, 27, 300000, 0, '2010-03-31', NULL, '');
INSERT INTO budget_budgetschedule VALUES (43, 27, 70000, 0, '2010-06-30', NULL, '');
INSERT INTO budget_budgetschedule VALUES (46, 44, 16000, 0, '2010-04-30', NULL, '');
INSERT INTO budget_budgetschedule VALUES (47, 45, 650000, 0, '2010-03-31', NULL, '');
INSERT INTO budget_budgetschedule VALUES (48, 45, 845340, 0, '2010-08-31', NULL, '');
INSERT INTO budget_budgetschedule VALUES (44, 53, 9346950, 0, '2010-01-01', NULL, '');
INSERT INTO budget_budgetschedule VALUES (45, 53, 9346950, 0, '2010-07-01', NULL, '');
INSERT INTO budget_budgetschedule VALUES (49, 53, 8500000, 0, '2010-01-01', NULL, '');
INSERT INTO budget_budgetschedule VALUES (50, 53, 8500000, 0, '2010-07-01', NULL, '');
INSERT INTO budget_budgetschedule VALUES (51, 53, 475900, 0, '2010-12-01', NULL, '');
INSERT INTO budget_budgetschedule VALUES (52, 48, 35400000, 0, '2010-02-15', NULL, '');
INSERT INTO budget_budgetschedule VALUES (53, 48, 17500000, 0, '2010-08-15', NULL, '');
INSERT INTO budget_budgetschedule VALUES (54, 48, 17500000, 0, '2011-02-15', NULL, '');
INSERT INTO budget_budgetschedule VALUES (55, 48, 14000000, 0, '2011-08-15', NULL, '');
INSERT INTO budget_budgetschedule VALUES (56, 48, 13500000, 0, '2012-02-15', NULL, '');
INSERT INTO budget_budgetschedule VALUES (57, 48, 500000, 0, '2012-08-31', NULL, '');
INSERT INTO budget_budgetschedule VALUES (26, 32, 7700000, 0, '2010-02-28', NULL, '');
INSERT INTO budget_budgetschedule VALUES (27, 32, 7000000, 0, '2010-05-31', NULL, '');


--
-- Data for Name: domain_project; Type: TABLE DATA; Schema: public; Owner: sms_dev
--

INSERT INTO domain_project VALUES (10, NULL, 2, '12345', NULL, 'โครงการอินเทอร์เน็ตปลอดภัยสร้างสรรค์', '', '', '2008-07-01', '2010-06-30', 0, '2010-04-09 09:51:17.898534+07', 4);
INSERT INTO domain_project VALUES (11, NULL, 2, '12348', NULL, 'โครงการFUSE', '', '', '2008-07-01', '2010-05-31', 0, '2010-04-12 11:48:33.451901+07', 4);
INSERT INTO domain_project VALUES (12, NULL, 2, '1234', NULL, 'serious game', '', '', '2010-02-01', '2010-02-26', 0, '2010-04-21 15:11:06.65676+07', 4);
INSERT INTO domain_project VALUES (13, NULL, 9, '53-00-0199', NULL, 'การศึกษาการระบาดของไข้หวัดใหญ่สายพันธ์ใหม่ 2009 ที่อำเภอทุ่งสง นครศรีธรรมราช', '', '', '2010-01-15', '2011-01-14', 0, '2010-06-22 09:51:54.791197+07', 4);


--
-- Data for Name: report_report; Type: TABLE DATA; Schema: public; Owner: sms_dev
--

INSERT INTO report_report VALUES (3, 13, NULL, 0, 'ตัวชี้วัดประจำไตรมาสที่ 1 (ตุลาคม - ธันวาคม)', true, true, '2010-04-18 13:21:16.261408+07', 1, 15, true);
INSERT INTO report_report VALUES (4, 13, NULL, 0, 'ตัวชี้วัดประจำไตรมาสที่ 2 (มกราคม - มีนาคม)', true, true, '2010-04-18 13:21:59.886308+07', 1, 15, true);
INSERT INTO report_report VALUES (5, 13, NULL, 0, 'ตัวชี้วัดประจำไตรมาสที่ 3 (เมษายน - มิถุนายน)', true, true, '2010-04-18 13:22:03.312314+07', 1, 15, true);
INSERT INTO report_report VALUES (6, 13, NULL, 0, 'ตัวชี้วัดประจำไตรมาสที่ 4 (กรกฎาคม - กันยายน)', true, true, '2010-04-18 13:26:58.947403+07', 1, 15, true);
INSERT INTO report_report VALUES (1, 13, NULL, 0, 'รายงานความก้าวหน้าประจำเดือนเมษายน', false, false, '2010-03-09 14:54:55.348084+07', 3, 15, true);
INSERT INTO report_report VALUES (7, 13, NULL, 0, 'รายงานสรุปการประชุมคณะกรรมการกำกับทิศทางครั้งที่ 5', true, true, '2010-04-19 20:33:20.468991+07', 3, 7, true);
INSERT INTO report_report VALUES (2, 13, NULL, 0, 'รายงานความก้าวหน้าประจำเดือน', true, false, '2010-04-08 11:45:44.16348+07', 1, 3, true);


--
-- Data for Name: report_reportsubmission; Type: TABLE DATA; Schema: public; Owner: sms_dev
--

INSERT INTO report_reportsubmission VALUES (1, 1, 2, '2010-03-10', NULL, 0, NULL);
INSERT INTO report_reportsubmission VALUES (2, 1, 2, '2010-04-10', NULL, 0, NULL);
INSERT INTO report_reportsubmission VALUES (5, 3, 2, '2010-04-30', NULL, 0, NULL);
INSERT INTO report_reportsubmission VALUES (6, 2, 2, '2010-04-15', NULL, 0, NULL);
INSERT INTO report_reportsubmission VALUES (7, 7, 2, '2010-04-30', '2010-04-19 20:41:46.869854+07', 1, NULL);
INSERT INTO report_reportsubmission VALUES (9, 2, 2, '2010-05-15', NULL, 0, NULL);
INSERT INTO report_reportsubmission VALUES (10, 3, 2, '2010-07-31', NULL, 0, NULL);
INSERT INTO report_reportsubmission VALUES (11, 4, 2, '2010-04-30', NULL, 0, NULL);
INSERT INTO report_reportsubmission VALUES (12, 7, 2, '2010-05-31', NULL, 0, NULL);
INSERT INTO report_reportsubmission VALUES (8, 1, 2, '2010-05-10', '2010-05-25 13:26:59.4684+07', 0, NULL);
INSERT INTO report_reportsubmission VALUES (13, 7, 2, '2010-06-30', NULL, 0, NULL);
INSERT INTO report_reportsubmission VALUES (14, 2, 9, '2010-04-15', NULL, 0, NULL);
INSERT INTO report_reportsubmission VALUES (17, 3, 9, '2010-04-30', NULL, 0, NULL);
INSERT INTO report_reportsubmission VALUES (18, 3, 9, '2010-07-31', NULL, 0, NULL);
INSERT INTO report_reportsubmission VALUES (20, 4, 9, '2010-10-31', NULL, 0, NULL);
INSERT INTO report_reportsubmission VALUES (21, 5, 9, '2010-04-30', NULL, 0, NULL);
INSERT INTO report_reportsubmission VALUES (22, 5, 9, '2011-01-31', NULL, 0, NULL);
INSERT INTO report_reportsubmission VALUES (23, 6, 9, '2010-04-30', NULL, 0, NULL);
INSERT INTO report_reportsubmission VALUES (24, 6, 9, '2011-04-30', NULL, 0, NULL);
INSERT INTO report_reportsubmission VALUES (26, 2, 2, '2010-06-15', NULL, 0, NULL);
INSERT INTO report_reportsubmission VALUES (16, 2, 9, '2010-06-15', '2010-06-22 13:18:33.698789+07', 1, NULL);
INSERT INTO report_reportsubmission VALUES (15, 2, 9, '2010-05-15', '2010-06-22 13:20:34.14279+07', 1, NULL);
INSERT INTO report_reportsubmission VALUES (19, 4, 9, '2010-04-30', '2010-06-22 13:23:19.410477+07', 1, NULL);
INSERT INTO report_reportsubmission VALUES (25, 1, 2, '2010-06-10', '2010-06-28 13:57:00.795027+07', 1, NULL);
INSERT INTO report_reportsubmission VALUES (28, 7, 2, '2010-07-31', NULL, 0, NULL);
INSERT INTO report_reportsubmission VALUES (29, 1, 2, '2010-07-10', NULL, 0, NULL);
INSERT INTO report_reportsubmission VALUES (30, 2, 2, '2010-07-15', '2010-07-22 11:45:36.362857+07', 1, NULL);
INSERT INTO report_reportsubmission VALUES (31, 2, 9, '2010-08-15', NULL, 0, NULL);
INSERT INTO report_reportsubmission VALUES (32, 3, 9, '2010-10-31', NULL, 0, NULL);
INSERT INTO report_reportsubmission VALUES (27, 2, 9, '2010-07-15', '2010-08-09 11:50:40.565429+07', 1, NULL);
INSERT INTO report_reportsubmission VALUES (33, 1, 2, '2010-08-10', NULL, 0, NULL);
INSERT INTO report_reportsubmission VALUES (35, 3, 2, '2010-10-31', NULL, 0, NULL);
INSERT INTO report_reportsubmission VALUES (36, 7, 2, '2010-08-31', NULL, 0, NULL);
INSERT INTO report_reportsubmission VALUES (34, 2, 2, '2010-08-15', '2010-08-31 11:11:53.678277+07', 1, NULL);


--
-- Data for Name: budget_budgetschedulereference; Type: TABLE DATA; Schema: public; Owner: sms_dev
--



--
-- Data for Name: budget_budgetschedulerevision; Type: TABLE DATA; Schema: public; Owner: sms_dev
--



--
-- Data for Name: comment_comment; Type: TABLE DATA; Schema: public; Owner: sms_dev
--



--
-- Data for Name: comment_commentreply; Type: TABLE DATA; Schema: public; Owner: sms_dev
--



--
-- Data for Name: comment_unreadcomment; Type: TABLE DATA; Schema: public; Owner: sms_dev
--



--
-- Data for Name: comment_unreadcommentreply; Type: TABLE DATA; Schema: public; Owner: sms_dev
--



--
-- Data for Name: django_admin_log; Type: TABLE DATA; Schema: public; Owner: sms_dev
--



--
-- Data for Name: django_session; Type: TABLE DATA; Schema: public; Owner: sms_dev
--



--
-- Data for Name: domain_activity; Type: TABLE DATA; Schema: public; Owner: sms_dev
--

INSERT INTO domain_activity VALUES (1, 10, 'การตรวจคัดเลือกร้านเข้าร่วมโครงการในพื้นที่กรุงเทพมหานคร(ครั้งที่1)', 'เปิดรับสมัครร้านเข้าร่วมโครงการและลงพื้นที่เพื่อตรวจรับรองมาตรฐานถึงการเป็นร้านเกมสีขาว พร้อมทั้งให้คำแนะนำในการปรับปรุงร้านให้มีความปลอดภัยต่อผู้ใช้งานโดยเฉพาะเด็กและเยาวชน', '2009-01-01', '2009-03-31', 0, '2010-04-09 09:55:18.679605+07', 4, 'กรุงเทพมหานคร', 'เพื่อเป็นการสร้างความตระหนักแก่ผู้ประกอบการให้มีการประกอบธุรกิจด้วยความรับผิดชอบ และเป็นไปตามระเบียบของกฎกระทรวงที่กำหนดไว้ป้องกันการประพฤติมิชอบของบางหน่วยงาน', 'มีผู้สนใจเข้าร่วมเพิ่มขึ้นจากเดิมประมาณ 115% และมีการขยายตัวของเครือข่ายภายในเขตพื้นที่กรุงเทพ 300% ปัญหาของการทุจริตลดลงอย่างชัดเจนเนื่องจากมีการเข้มงวดจากหลายหน่วยงานประกอบกัน');
INSERT INTO domain_activity VALUES (2, 10, 'การตรวจคัดเลือกร้านเข้าร่วมโครงการในพื้นที่กรุงเทพมหานคร(ครั้งที่2)', 'เปิดรับสมัครร้านเข้าร่วมโครงการและลงพื้นที่เพื่อตรวจรับรองมาตรฐานถึงการเป็นร้านเกมสีขาว พร้อมทั้งให้คำแนะนำในการปรับปรุงร้านให้มีความปลอดภัยต่อผู้ใช้งานโดยเฉพาะ เด็กและเยาวชน', '2010-06-01', '2010-09-30', 0, '2010-04-12 11:13:20.31222+07', 4, 'กรุงเทพมหานคร', '', '');
INSERT INTO domain_activity VALUES (3, 10, 'การตรวจคัดเลือกร้านเข้าร่วมโครงการในพื้นที่ต่างจังหวัด', 'เปิดรับสมัครร้านเข้าร่วมโครงการและลงพื้นที่เพื่อตรวจรับรองมาตรฐานถึงการ เป็นร้านเกมสีขาว พร้อมทั้งให้คำแนะนำในการปรับปรุงร้านให้มีความปลอดภัยต่อผู้ใช้งานโดยเฉพาะ เด็กและเยาวชน', '2009-06-01', '2009-09-30', 0, '2010-04-12 11:16:28.524609+07', 4, 'ทั่วประเทศ', '', '');
INSERT INTO domain_activity VALUES (4, 10, 'ผลักดันหลักสูตรอินเทอร์เน็ตปลอดภัยสร้างสรรค์', 'หลังจากที่ในแผนงานระยะที่ 1 ได้พัฒนาหลักสูตรอินเทอร์เน็ตปลอดภัยและสร้างสรรค์เพื่อใช้ในการเผยแพร่ความรู้เท่าทันสื่ออินเทอร์เน็ต แต่ยังมีอุปสรรคในการเผยแพร่ให้มีการรับรู้ในวงกว้าง ดังนั้นในแผนงานในระยะที่ 2 จึงมีการดำเนินการอย่างต่อเนื่องโดยเฉพาะการหาช่องทางในการเผยแพร่หลักสูตรดังกล่าวกระจายออกไปให้มากที่สุด', '2008-07-01', '2010-05-31', 0, '2010-04-12 11:31:19.487316+07', 4, 'ทั่วประเทศ', 'หลักสูตรต้องได้รับการรับรองจากสำนักงานคณะกรรมการการศึกษาขั้นพื้นฐานเพื่อเป็นหลักสูตรมตรฐานที่โรงเรียนทั่วไปสามารถนำไปใช้เพื่อการเรียนการสอนต่อไปได้ และเป็นหนึ่งในเครื่องมือประเมินเพื่อเป็นแรงจูงใจแก่ครูผู้นำไปใช้', 'กำลังอยู่ในระหว่างรอการตอบรับจากสำนักงานคณะกรรมการการศึกษาขั้นพื้นฐาน แต่มีการนำหลักสูตรไปเผยแพร่ในกลุ่มครู สสวท. ซึ่งเป็นเครือข่ายของครูคอมพิวเตอร์และการประกวดสื่อดิจิทัล');
INSERT INTO domain_activity VALUES (5, 10, ' คณะกรรมการสื่อปลอดภัยสร้างสรรค์แห่งชาติ', 'คณะกรรมการสื่อปลอดภัยและสร้างสรรค์แห่งชาติ เป็นหนึ่งในงานต่อเนื่องจากแผนงานระยะที่ 1 โดยคณะกรรมการดังกล่าวเป็นการสร้างกระบวนการของการทำงานบูรณาการหลายกระทรวงเข้าด้วยกันโดยมีการวางยุทธศาสตร์ ขจัดสื่อร้าย ขยายสื่อดี สร้างภูมิคุ้มกัน เพื่อตอบสนองต่อปัญหาที่เกิดจากการเสพย์สื่อที่นับวันจะยิ่งมีอิทธิพลต่อความคิดและพฤติกรรมของคนในสังคม', '2008-07-01', '2010-05-31', 0, '2010-04-12 11:40:56.190398+07', 4, 'ทั่วประเทศ', 'กลไกอย่างหนึ่งของความยั่งยืนของคณะกรรมการที่ยังไม่ได้เกิดขึ้นขึ้นในระยะแรกคือ กองทุนสื่อปลอดภัยสร้างสรรค์ อันมีความสำคัญสำหรับการพัฒนาสื่อที่ดีมีุคุณภาพและเป็นแรงจูงใจให้เกิดการพัฒนาสื่อที่ดีมากยิ่งขึ้น', 'ได้มีการนำเสนอร่างกองทุนสื่อปลอดภัยและสร้างสรรค์ในที่ประชุม ครม เดือนมีนาคม 2553');
INSERT INTO domain_activity VALUES (6, 11, 'ฟิ้วส์แค้ม', '', NULL, NULL, 0, '2010-04-19 17:37:46.093699+07', 4, 'TK Park', '', '');
INSERT INTO domain_activity VALUES (7, 10, 'ประชุมคณะกรรมการกำกับทิศทาง', '', '2010-05-31', '2010-05-31', 0, '2010-04-20 19:15:37.584435+07', 4, 'SM Tower', '', '');


--
-- Data for Name: kpi_domainkpicategory; Type: TABLE DATA; Schema: public; Owner: sms_dev
--

INSERT INTO kpi_domainkpicategory VALUES (2, NULL, NULL, 'ผลงานวิจัย ชุดความรู้ เอกสารวิชาการ คู่มือ ต้นแบบ ฯลฯ');
INSERT INTO kpi_domainkpicategory VALUES (3, NULL, NULL, 'ข้อเสนอเชิงนโยบายในระดับนานาชาติ ระดับชาติ หรือระดับท้องถิ่น');
INSERT INTO kpi_domainkpicategory VALUES (4, NULL, NULL, 'ปัญหาและประเด็นเร่งด่วน');
INSERT INTO kpi_domainkpicategory VALUES (5, NULL, NULL, 'กลไก เครื่องมือ หรือเครือข่าย');
INSERT INTO kpi_domainkpicategory VALUES (1, NULL, NULL, 'พัฒนาระบบเชิงนโยบาย เชิงประเด็น และเชิงพื้นที่');


--
-- Data for Name: kpi_domainkpi; Type: TABLE DATA; Schema: public; Owner: sms_dev
--

INSERT INTO kpi_domainkpi VALUES (5, NULL, NULL, NULL, 1, 'R4', 'ปัญหาเร่งด่วนและประเด็นที่สังคมให้ความสนใจในวงกว้างได้รับการจัดการอย่างทันท่วงที', '', 2010, 'ประเด็น');
INSERT INTO kpi_domainkpi VALUES (7, 13, NULL, NULL, 1, 'R1', 'เกิดการพัฒนาระบบข้อมูลและการใช้สารสนเทศ และการเชื่อมโยงข้อมูลด้านสุขภาวะที่นำไปสู่การใช้ประโยชน์เชิงนโยบาย เชิงประเด็น และเชิงพื้นที่', '', 2010, 'ระบบ');
INSERT INTO kpi_domainkpi VALUES (9, 13, NULL, NULL, 3, 'R3', 'เกิดข้อเสนอเชิงนโยบายในระดับนานาชาติ ระดับชาติ หรือระดับท้องถิ่นที่เกี่ยวข้องกับสุขภาวะ และเกิดร่างกฎหมาย กฎ ระเบียบ ประกาศ ข้อบัญญัติท้องถิ่นที่เกี่ยวข้องกับสุขภาวะ', '', 2010, 'ข้อเสนอ');
INSERT INTO kpi_domainkpi VALUES (10, 13, NULL, NULL, 2, 'R2', 'เกิดผลงานวิจัย ชุดความรู้ เอกสารวิชาการ คู่มือ ต้นแบบหรือแนวปฏิบัติที่ดีที่ได้จากการศึกษาวิจัย', '', 2010, 'เรื่อง');
INSERT INTO kpi_domainkpi VALUES (11, 13, NULL, NULL, 4, 'R4', 'ปัญหาเร่งด่วนและประเด็นที่สังคมให้ความสนใจในวงกว้างได้รับการจัดการอย่างทันท่วงที', '', 2010, 'ประเด็น');
INSERT INTO kpi_domainkpi VALUES (12, 13, NULL, NULL, 5, 'R5', 'เกิดกลไก เครื่องมือ หรือเครือข่ายในการส่งเสริมความเป็นธรรมในสังคม การแก้ไขปัญหาความไม่เป็นธรรม หรือการเยียวยาผู้ได้รับผลกระทบจากความไม่เป็นธรรม เพื่อเสริมสร้างสุขภาวะทางสังคม', '', 2010, 'กลไก');
INSERT INTO kpi_domainkpi VALUES (1, NULL, NULL, NULL, 1, 'R1', 'เกิดการพัฒนาระบบข้อมูลและการใช้สารสนเทศ และการเชื่อมโยงข้อมูลด้านสุขภาวะที่นำไปสู่การใช้ประโยชน์เชิงนโยบาย เชิงประเด็น และเชิงพื้นที่', '', 2010, 'ระบบ');
INSERT INTO kpi_domainkpi VALUES (3, NULL, NULL, NULL, 1, 'R2', 'เกิดผลงานวิจัย ชุดความรู้ เอกสารวิชาการ คู่มือ ต้นแบบหรือแนวปฏิบัติที่ดีที่ได้จากการศึกษาวิจัย', '', 2010, 'เรื่อง');
INSERT INTO kpi_domainkpi VALUES (4, NULL, NULL, NULL, 1, 'R3', 'เกิดข้อเสนอเชิงนโยบายในระดับนานาชาติ ระดับชาติ หรือระดับท้องถิ่นที่เกี่ยวข้องกับสุขภาวะ และเกิดร่างกฎหมาย กฎ ระเบียบ ประกาศ ข้อบัญญัติท้องถิ่นที่เกี่ยวข้องกับสุขภาวะ', '', 2010, 'ข้อเสนอ');
INSERT INTO kpi_domainkpi VALUES (6, NULL, NULL, NULL, 1, 'R5', 'เกิดกลไก เครื่องมือ หรือเครือข่ายในการส่งเสริมความเป็นธรรมในสังคม การแก้ไขปัญหาความไม่เป็นธรรม หรือการเยียวยาผู้ได้รับผลกระทบจากความไม่เป็นธรรม เพื่อเสริมสร้างสุขภาวะทางสังคม', '', 2010, 'กลไก');
INSERT INTO kpi_domainkpi VALUES (13, NULL, NULL, NULL, 5, 'ICTP1', 'เกิดเครือข่ายออนไล์ด้านดีในชุมชนออนไลน์', '', 2010, 'เปอร์เซ็นต์');
INSERT INTO kpi_domainkpi VALUES (16, NULL, NULL, NULL, 2, 'ICTP2', 'การสนับสนุนภาคีระดับแผนงานของ สสส.', '', 2010, 'เปอร์เซ็นต์');


--
-- Data for Name: kpi_domainkpischedule; Type: TABLE DATA; Schema: public; Owner: sms_dev
--

INSERT INTO kpi_domainkpischedule VALUES (3, 13, 2, 20, 15, 1, 2010, '');
INSERT INTO kpi_domainkpischedule VALUES (4, 16, 2, 60, 58, 1, 2010, '');
INSERT INTO kpi_domainkpischedule VALUES (5, 3, 48, 7, 0, 1, 2010, '');
INSERT INTO kpi_domainkpischedule VALUES (6, 4, 48, 2, 0, 1, 2010, '');
INSERT INTO kpi_domainkpischedule VALUES (7, 1, 48, 1, 0, 1, 2010, '');


--
-- Data for Name: kpi_domainkpischedulereference; Type: TABLE DATA; Schema: public; Owner: sms_dev
--



--
-- Data for Name: registration_registrationprofile; Type: TABLE DATA; Schema: public; Owner: sms_dev
--



--
-- Data for Name: report_reportassignment; Type: TABLE DATA; Schema: public; Owner: sms_dev
--

INSERT INTO report_reportassignment VALUES (1, 1, 2, false);
INSERT INTO report_reportassignment VALUES (3, 3, 2, true);
INSERT INTO report_reportassignment VALUES (4, 4, 2, false);
INSERT INTO report_reportassignment VALUES (2, 2, 2, false);
INSERT INTO report_reportassignment VALUES (5, 7, 2, true);
INSERT INTO report_reportassignment VALUES (6, 2, 9, true);
INSERT INTO report_reportassignment VALUES (7, 3, 9, true);
INSERT INTO report_reportassignment VALUES (8, 4, 9, true);
INSERT INTO report_reportassignment VALUES (9, 5, 9, true);
INSERT INTO report_reportassignment VALUES (10, 6, 9, true);


--
-- Data for Name: report_reportduedates; Type: TABLE DATA; Schema: public; Owner: sms_dev
--



--
-- Data for Name: report_reportduerepeatable; Type: TABLE DATA; Schema: public; Owner: sms_dev
--



--
-- Data for Name: report_reportsubmissionfileresponse; Type: TABLE DATA; Schema: public; Owner: sms_dev
--

INSERT INTO report_reportsubmissionfileresponse VALUES (1, 1, '20100318-ICT-plan-progress-and-summary-mar53.pdf', '2010-03-25 13:41:52.677195+07', 3);
INSERT INTO report_reportsubmissionfileresponse VALUES (2, 7, '20100318-ICT-plan-progress-and-summary-mar53.doc', '2010-04-19 20:41:23.410757+07', 3);
INSERT INTO report_reportsubmissionfileresponse VALUES (23, 8, 'สรุปผลการดำเนินงานApr-May10.doc', '2010-05-26 08:31:50.902905+07', 5);
INSERT INTO report_reportsubmissionfileresponse VALUES (26, 17, 'graph  ส่ง สสส มิย 53.doc', '2010-06-22 13:15:56.969034+07', 19);
INSERT INTO report_reportsubmissionfileresponse VALUES (27, 16, 'graph  ส่ง สสส มิย 53.doc', '2010-06-22 13:18:22.472348+07', 19);
INSERT INTO report_reportsubmissionfileresponse VALUES (28, 15, 'รายงานการเงินงวดที่ 1.xls', '2010-06-22 13:20:30.78935+07', 19);
INSERT INTO report_reportsubmissionfileresponse VALUES (29, 19, 'action plan.xls', '2010-06-22 13:23:16.492148+07', 19);
INSERT INTO report_reportsubmissionfileresponse VALUES (30, 31, 'กราฟส่ง สสส 9สค.53.ppt', '2010-08-09 11:47:56.711689+07', 19);
INSERT INTO report_reportsubmissionfileresponse VALUES (31, 27, 'กราฟส่ง สสส 9สค.53.ppt', '2010-08-09 11:50:27.238303+07', 19);


--
-- Data for Name: report_reportsubmissionreference; Type: TABLE DATA; Schema: public; Owner: sms_dev
--



--
-- Data for Name: report_reportsubmissiontextresponse; Type: TABLE DATA; Schema: public; Owner: sms_dev
--

INSERT INTO report_reportsubmissiontextresponse VALUES (8, '<p>&nbsp;สรุปความคืบหน้า และสรุปผลการดำเนินงาน<br />

แผนงาน ICT เพื่อสุขภาวะออนไลน์และการสนับสนุนภาคีเครือข่าย<br />

เมษายน &ndash; พฤษภาคม 2553<br />

ความคืบหน้าด้านสุขภาวะออนไลน์<br />

1. ระบบ SMS เพื่อการเฝ้าระวังโรคระบาด<br />

ความร่วมมือกับสำนักระบาดวิทยา ได้สนับสนุนระบบ SMS เพื่อแจ้งสถานะอัตราผู้ป่วยอาการคล้ายไข้หวัดใหญ่ (ILI) ไปยังจังหวัดต่าง ๆ และแจ้งเตือนการส่งรายงานล่าช้า ต่อเนื่องมาเป็นสัปดาห์ที่ 19 ของปี 2553 ส่งผลให้การรายงาน ILI มีประสิทธิภาพมากขึ้นดดยมีการส่งข้อมูลตรงเวลามากขึ้นถึง 60% จากระบบเดิมที่ส่งข้อมูลตรงเวลาที่ 10%<br />

ความร่วมมือกับ MBDS ได้จัดอบรมเพื่อขยายกลุ่ม SRRT เพื่อใช้งานระบบ SMS เพื่อการเฝ้าระวังโรคระบาด ในพื้นที่จังหวัดเชียงรายเป็น 23 กลุ่ม จำนวนผู้ใช้งานกว่า 280 คน<br />

<br />

จัดการอบรมเพื่อทดลองใช้ระบบ Geochat ที่แขวงบ่อแก้ว สปป.ลาว เพื่อเป็นเครื่องมือสื่อสารระหว่าง SRRT ของแขวงบ่อแก้ว<br />

<br />

2. เปิดตัวเว็บไซต์ Healthygamer.net<br />

<br />

ได้เปิดตัวเว็บไซต์ Healthygamer.net ในงานสัมมนาของคณะกรรมการวิจัยแห่งชาติ เมื่อวันทีี่ 4 พฤษภาคม 2553<br />

ซึ่งนับตั้งแต่เปิดตัวจนถึงวันที่ 20 พ.ค.2553&nbsp; มีผู้เข้าชมแล้วกว่า 1200 ราย<br />

3. โครงการเครือข่ายห้องสมุดดิจิทัลประเทศไทย<br />

ด้านเนื้อหา<br />

รวบรวมหนังสือเรียนภาษาไทย หลักสูตร พ.ศ.2521 ชุดมานะมานี ให้บริการอ่านและดาวน์โหลดออนไลน์ผ่านหน้าเว็บเครือข่ายห้องสมุดดิจิทัลประเทศไทย (dlib.in.th)<br />

กำลังดำเนินการสแกนสารานุกรมวัฒนธรรมภาคใต้ 18 เล่ม จะเสร็จพร้อมให้บริการออนไลน์ผ่านเว็บไซต์เครือข่ายห้องสมุดดิจิทัลประเทศไทย และสถาบันทักษิณคดีศึกษา ภายในสิ้นเดือนกรกฎาคม 2553<br />

ด้านกิจกรรม<br />

จัดเวทีสัมมนามาตรฐานสื่อดิจิทัล<br />

ร่วมกับสวทช. ที่มหาวิทยาลัยเชียงใหม่ ระหว่างวันที่ 22-23 เมษายน 2553<br />

โดยมีการบรรยายและจัดทำ Roadmap การพัฒนามาตรฐานสื่อดิจิทัลในเครือข่ายห้องสำนักหอสมุดมหาวิทยาลัยเชียงใหม่ มีผู้เข้าร่วมกว่า 100 คนจากสถาบันการศึกษาต่างๆ ในภาคเหนือ<br />

&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;<br />

<br />

ด้านความร่วมมือ<br />

ร่วมมือกับสำนักหอสมุด มหาวิทยาลัยเกษตรศาสตร์ในการพัฒนาเครือข่ายคลังความรู้งานวิจัยด้านการเกษตรแห่งชาติ ภายใต้โครงการห้องสมุดดิจิทัลเกษตรไทย ที่ได้รับความร่วมมืออย่างกว้างขวาง เช่นจากกรมวิชาการเกษตร กรมส่งเสริมการเกษตร สกว. สภาวิจัยแห่งชาติ FAO เป็นต้น โดยปัจจุบันอยู่ในระหว่างการร่าง MOU ร่วมกัน<br />

ร่วมมือกับสำนักงานพัฒนาวิทยาศาสตร์และเทคโนโลยีแห่งชาติ (สวทช.) ในการพัฒนาฐานข้อมูลบรรณานุกรมหนังสือแห่งชาติ โดยปัจจุบันอยู่ในระหว่างการร่าง MOU ร่วมกัน<br />

<br />

ด้านการสนับสนุนภาคีเครือข่าย<br />

สนับสนุนสำนักงานหลักประกันสุขภาพแห่งชาติ (สปสช.) ในการพัฒนาระบบฐานข้อมูลภูมิศาสตร์ (GIS) ของเครือข่ายมิตรภาพบำบัด ซึ่งเป็นแนวทางการดูแลรักษาผู้ป่วยอย่างเคารพความเป็นมนุษย์ ตามระยะต่างๆ ของโรคยอดนิยม เช่น โรคหัวใจ โรคไต โรคมะเร็ง โรคเอดส์ และผู้พิการ โดยระบบ GIS ดังกล่าวจะช่วยให้สปสช. สามารถบริหารจัดการและสนับสนุนเครือข่ายมิตรภาพบำบัดให้มีประสิทธิภาพ สอดคล้องกับความต้องการและสถานการณ์ในพื้นที่ได้มากขึ้น<br />

ให้คำปรึกษาสำนักหอสมุด มหาวิทยาลัยเชียงใหม่ ในการปรับปรุงและพัฒนาระบบเว็บไซต์ห้องสมุดดิจิทัลในเครือข่ายห้องสำนักหอสมุดมช.<br />

<br />

ความคืบหน้าด้านสนับสนุนภาคีเครือข่าย<br />

4. ระบบต้นแบบการจัดการข้อมูลแผนงานและโครงการสำนัก 7<br />

แผนงานไอซีทีฯ ได้พัฒนาระบบต้นแบบเพื่อจัดการแผนงานและโครงการของสำนัก 7 โดยระบบสามารถแสดงผลภาพรวมเพื่อให้ผู้อำนวยการสำนักฯ เห็นความก้าวหน้าของแผนหลัก แผนงานภายใต้แผนหลัก และโครงการย่อยต่างๆ ในมิติด้านตัวชี้วัด และงบประมาณ<br />

ระบบฯ ยังเอื้อให้ผู้ประสานงานของสำนัก ฯ และผู้จัดการโครงการ รับ-ส่งข้อมูลความคืบหน้าของโครงการในแต่ละตัวชี้วัด และรายงานต่าง ๆ รวมทั้งการเบิกจ่ายงบประมาณตามงวด<br />

5. ปิ๊งส์ (Pings.in.th)<br />

โครงการ &quot;ปิ๊งส์&quot;เป็นโครงการที่ &ldquo;แผนงานทุนอุปถัมภ์&nbsp;&nbsp;&nbsp;&nbsp; เชิงรุกเพื่อสื่อศิลปวัฒนธรรมและกิจกรรมสร้างสรรค์&rdquo; หนึ่งในแผนงานของ&ldquo;สำนักงานกองทุนสนับสนุนการสร้างเสริมสุขภาพ&rdquo; ( สสส. ) จัดขึ้น เพื่อสนับสนุนให้เยาวชน นักเรียน นิสิต นักศึกษาจากทั่วประเทศ ได้ลงมือออกแบบและผลิตสื่อหรือกิจกรรมที่สร้างสรรค์ด้วยตัวเอง ด้วยการจับมือกับเหล่าภาคีเครือข่ายพันธมิตรด้านสื่อและเครือข่ายด้าน ประเด็นสุขภาวะและสังคม ไม่จำกัดว่าเป็นรัฐหรือเอกชน<br />

<br />

<br />

&nbsp;&nbsp;&nbsp;&nbsp; เยาวชนที่ผ่านการคัดเลือกจะได้เข้าร่วมเวิร์คช็อปผลิตสื่อที่เกี่ยวข้องกับ ประเด็นสุขภาวะและสังคม เพื่อเพิ่มช่องทางให้เยาวชนได้ใส่ใจกับปัญหาต่างๆ รอบตัวเป็นการสร้างเสริมสุขภาพทางความคิด สติปัญญา อารมณ์และสังคม พัฒนาทักษะการทำงานร่วมกับผู้อื่น ผ่านกิจกรรมการสร้างสรรค์สื่อต่างๆ ที่สนใจในการอบรมที่เกิดขึ้น และต่อยอดด้วยการสนับสนุนทุนโครงการเพื่อพัฒนางานที่ได้ให้เป็นจริงต่อไป<br />

&nbsp;&nbsp; &nbsp;ทางแผนงาน ICT จึงมีส่วนเข้าไปช่วยจัดทำเว็บไซต์ Pings.in.th เพื่อเปิดพื้นที่ให้เยาวชนที่สนใจการผลิตสื่อภายใต้ประเด็นดีๆส่งเสริมสุข ภาวะและสังคมได้เข้ามาเป็นส่วนหนึ่งของโครงการได้ ไม่ว่าจะเรียนรู้การอบรมสื่อต่างๆที่ผ่านไปแล้ว การปล่อยผลงานดีๆของตัวเองให้ผู้ใหญ่ใจดีได้แนะนำติชม<br />

สร้างการแลกเปลี่ยนเรียนรู้ผ่านหน้าเว็บไซต์ การสร้างเครือข่ายเยาวชนที่สนใจในสื่อหรือประเด็นแบบเดียวกัน ด้วยระบบสมาชิกที่น้องๆเยาวชน สามารถติดต่อและพูดคุยกันได้อย่างง่ายดาย รวมถึงการสะสมแต้มเพื่อแลกรับสิทธิประโยชน์ต่างๆจากโครงการด้วย<br />

&nbsp;&nbsp; &nbsp;ซึ่ง ณ ตอนนี้เว็บไซต์ pings ได้เปิดให้กลุ่มสมาชิกได้ทดลองใช้เบื้องต้นแล้ว และพร้อมกันนี้ก็ได้พัฒนาระบบข้างหลังให้เรียบร้อยด้วย<br />

<br />

6. เว็บไซต์ศูนย์ข้อมูล สสส. (Info.thaihealth.or.th)<br />

เว็บไซต์ info.thaihealth.or.th เป็นเว็บที่รวมข้อมูลที่เกี่ยวข้องกับสุขภาพไว้ทุกรูปแบบ เช่น หนังสือ บทความ งานวิจัย ข้อมูลวิชาการ เป็นต้น โดยสามารถที่จะเลือกอ่านออนไลน์ หรือจะโหลดเก็บไว้ก็ได้<br />

ซึ่งหลังจากเว็บไซต์ info.thaihealth.or.th ได้เปิดตัวไปเมื่อเดือนมกราคม ปี 2553&nbsp; นั้น ก็ได้มีแผนที่จะทำการปรับเว็บไซต์ info ใหม่ทั้งหมด เพื่อให้ผู้ใช้ได้เข้าถึงข้อมูลต่างๆได้ง่ายขึ้น<br />

เว็บไซต์ info.thaihealth.or.th ปัจจุบัน<br />

<br />

&nbsp; &nbsp;&nbsp;&nbsp; โดยการปรับเว็บไซต์ครั้งนี้ ได้มีการปรับดีไซน์ของเว็บใหม่ทั้งหมด ปรับการแสดงผลในส่วนของข้อมูลต่างๆ รวมไปถึงการจัดหมวดหมู่ของข้อมูลใหม่เพื่อให้ค้นหาและเข้าถึงข้อมูลเป็นไปได้ง่ายขึ้น<br />

ซึ่งคาดว่าเว็บไซต์ info.thaihealth.or.th ที่ได้ทำการปรับใหม่นี้จะแล้วเสร็จภายในเดือนพฤษภาคมนี้<br />

&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; เว็บไซต์ info.thaihealth.or.th ที่ปรับใหม่<br />

7. เว็บไซต์องค์กร สสส. (corp.thaihealth.or.th)<br />

<br />

เนื่องจากปัจจุบัน เว็บไซต์ thaihealth.or.th มีเนื้อหาค่อนข้างเยอะ จึงได้มีการแยกข้อมูลในส่วนของข้อมูลองค์กร สสส. นั้น ออกมาจากเว็บ thaihealth.or.th เป็นอีกเว็บหนึ่งคือ http://corp.thaihealth.or.th เพื่อสะดวกในการเข้าถึงข้อมูลของผู้ใช้<br />

<br />

<br />

<br />

เว็บไซต์ corp.thaihealth.or.th</p>

', '2010-05-25 13:26:39.583781+07', 5);
INSERT INTO report_reportsubmissiontextresponse VALUES (25, '<p><font face="Tahoma"><font face="Tahoma, sans-serif"><b>รายงานความก้าวหน้<wbr>าของ แผนงานไอซีที ประจำเดือน </wbr></b></font></font><wbr><wbr><font face="Tahoma, sans-serif"><b>16 </b></font><font face="Tahoma"><font face="Tahoma, sans-serif"><b>พ</b></font></font><font face="Tahoma, sans-serif"><b>.</b></font><font face="Tahoma"><font face="Tahoma, sans-serif"><b>ค</b></font></font><font face="Tahoma, 

sans-serif"><b>. &ndash; 15 </b></font><font face="Tahoma"><font face="Tahoma, sans-serif"><b>มิ</b></font></font><font face="Tahoma, sans-serif"><b>.</b></font><font face="Tahoma"><font face="Tahoma, sans-serif"><b>ย</b></font></font><font face="Tahoma, 

sans-serif"><b>. 53</b></font>

<ul>

	<li>

		<p align="LEFT" style="margin-bottom: 0.14in; line-height: 115%;"><font face="Tahoma"><font face="Tahoma, sans-serif"><b>พัฒนาแผนระยะที่ </b></font></font><font face="Tahoma, sans-serif"><b>3 </b></font><font face="Tahoma"><font face="Tahoma, sans-serif"><b>เน้น เรื่องไอซีทีเพื่อสร้างเสริ<wbr>มสุขภาวะทางปัญญา และการใช้เครื่องมือไอซีทีเพื่<wbr>อสนับสนุนการทำงานของภาคีสร้<wbr>างพื้นที่ สุขภาวะ ทั้งนี้ได้นำเสนอต่อกรรมการกำกั<wbr>บทิศทางของแผนงาน และ อยู่ในระหว่<wbr>างกระบวนการระดมสมองจากผู้ที่<wbr>เคยร่วมงานกับแผน งาน ฯ เพื่อปรับปรุงแผนระยะที่ </wbr></wbr></wbr></wbr></wbr></wbr></b></font></font><font face="Tahoma, sans-serif"><b>3 </b></font><font face="Tahoma"><font face="Tahoma, sans-serif"><b>ให้ สมบูรณ์ขึ้น</b></font></font></p>

	</li>

</ul>

<wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr>

<p align="LEFT" style="margin-bottom: 0.14in; line-height: 115%;"><font face="Tahoma"><font face="Tahoma, sans-serif"><b>ด้านสุขภาวะออ นไลน์</b></font></font></p>

<ul>

	<li>

		<p align="LEFT" style="margin-bottom: 0.14in; line-height: 115%;"><font face="Tahoma"><font face="Tahoma, sans-serif"><b>หลังเหตุการณ์ ความไม่<wbr>สงบแผนงานไอซีที เป็นส่วนหนึ่งในการใช้เครือข่<wbr>ายทางสังคม </wbr></wbr></b></font></font><font face="Tahoma, sans-serif"><b>Facebook </b></font><font face="Tahoma"><font face="Tahoma, sans-serif"><b>ในนาม กลุ่ม </b></font></font><font face="Tahoma, sans-serif"><b>Thai peace</b></font><font face="Tahoma"><font face="Tahoma, sans-serif"><b> เพื่อระดมอาสาสมัครในวัน </b></font></font><font face="Tahoma, sans-serif"><b>Big Cleaning Day</b></font></p>

	</li>

</ul>

<wbr><wbr><wbr><wbr>

<p align="LEFT" style="margin-bottom: 0.14in; line-height: 115%;"><font face="Tahoma"><font face="Tahoma, sans-serif"><b>ด้านการสนับสนุน ภาคีเครือข่าย</b></font></font></p>

<ul>

	<li>

		<p align="LEFT" style="margin-bottom: 0.14in; line-height: 115%;"><font face="Tahoma"><font face="Tahoma, sans-serif"><b>ออกแบบเว็บไซต์ ให้คณะกรรมการสื่<wbr>อปลอดภัยสร้างสรรค์</wbr></b></font></font></p>

	</li>

</ul>

<wbr><wbr>

<ul>

	<li>

		<p align="LEFT" style="margin-bottom: 0.14in; line-height: 115%;"><font face="Tahoma"><font face="Tahoma, sans-serif"><b>พัฒนาระบบบริหาร แผนงานเพื่<wbr>อการบริหารติดตามแผนงานของสำนัก </wbr></b></font></font><font face="Tahoma, sans-serif"><b>7 </b></font><font face="Tahoma"><font face="Tahoma, sans-serif"><b>โดย เป็นระบบที่ใช้งานระหว่างผู้<wbr><wbr><wbr>จัดการแผนงาน</wbr></wbr></wbr></b></font></font><font face="Tahoma, sans-serif"><b>/</b></font><font face="Tahoma"><font face="Tahoma, sans-serif"><b>ผู้ประสานงาน</b></font></font><font face="Tahoma, sans-serif"><b>/</b></font><font face="Tahoma"><font face="Tahoma, sans-serif"><b>ผู้<wbr><wbr><wbr><wbr><wbr><wbr>อำนวยการสำนัก</wbr></wbr></wbr></wbr></wbr></wbr></b></font></font></p>

	</li>

	<li>

		<p align="LEFT" style="margin-bottom: 0.14in; line-height: 115%;"><font face="Tahoma"><font face="Tahoma, sans-serif"><b>พัฒนาระบบต้นแบบ บริหารแผนงานเพื<wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr>่อการบริหารติดตามแผนงานของสำนั<wbr>กงาน สสส</wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></b></font></font><font face="Tahoma, sans-serif"><b>. </b></font><font face="Tahoma"><font face="Tahoma, sans-serif"><b>โดย เป็นระบบที่ใช้งานระหว่าง ผู้ประสานงาน</b></font></font><font face="Tahoma, sans-serif"><b>/</b></font><font face="Tahoma"><font face="Tahoma, sans-serif"><b>ผู้อำนวยการสำนัก</b></font></font><font face="Tahoma, sans-serif"><b>/</b></font><font face="Tahoma"><font face="Tahoma, sans-serif"><b><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr>ผู้จัดการกองทุนฯ</wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></b></font></font></p>

	</li>

	<li>

		<p align="LEFT" style="margin-bottom: 0.14in; line-height: 115%;"><font face="Tahoma"><font face="Tahoma, sans-serif"><b>ร่วมกิจกรรม ประชุมเชิงปฏิบัติ<wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr>การด้านไอซีทีเพื่อองค์<wbr>กรสาธารณประโยชน์ในภูมิ ภาคลุ่<wbr>มแม่นำ้โขง </wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></b></font></font><font face="Tahoma, sans-serif"><b>(Mekong ICT Camp) </b></font><font face="Tahoma"><font face="Tahoma, sans-serif"><b>ที่ จ</b></font></font><font face="Tahoma, sans-serif"><b>.</b></font><font face="Tahoma"><font face="Tahoma, sans-serif"><b>เชียงใหม่ โดยแผนงานไอซีที ได้นำเสนองานด้านการเฝ้าระวั<wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr>งโรคระบาดในพื้นที่ลุ่มแม่นำ้<wbr>โขง</wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></b></font></font></p>

	</li>

</ul>

</wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></p>

', '2010-06-28 13:56:22.98335+07', 3);
INSERT INTO report_reportsubmissiontextresponse VALUES (30, '<p>&nbsp; <font face="Tahoma"><font face="Tahoma, sans-serif"><b>สุขภาวะออนไลน์</b></font></font></p>

<ul>

	<li>

		<p align="LEFT" style="margin-bottom: 0.14in; line-height: 115%;"><font face="Tahoma"><font face="Tahoma, sans-serif"><b>โครงการห้องสมุดดิจิทัล เข้าพบผู้อำนวยการหอสมุดมหาวิ<wbr>ทยาลัยเกษตรศาสตร์ เพื่อเตรียมลงนามบันทึกความเข้าใจ </wbr></b></font></font><font face="Tahoma, sans-serif"><b>(MOU) </b></font><font face="Tahoma"><font face="Tahoma, sans-serif"><b>ความร่วมมือด้านการเชื่อมโยงข้<wbr><wbr><wbr><wbr>อมูลสารสนเทศด้านการเกษตร</wbr></wbr></wbr></wbr></b></font></font></p>

		<p align="LEFT" style="margin-bottom: 0.14in; line-height: 115%;">&nbsp;</p>

	</li>

</ul>

<p><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr>

<p><wbr><wbr><wbr><wbr>

<p align="LEFT" style="margin-bottom: 0.14in; line-height: 115%;"><wbr><font face="Tahoma"><font face="Tahoma, sans-serif"><b>การสนับสนุนภาคีเครือข่าย</b></font></font></wbr></p>

<wbr>

<ul>

	<li>

		<p align="LEFT" style="margin-bottom: 0.14in; line-height: 115%;"><font face="Tahoma"><font face="Tahoma, sans-serif"><b>พัฒนาระบบต้นแบบบริหารแผนงานเพื<wbr>่อการบริหารติดตามแผนงานของสำนั<wbr>กงาน สสส</wbr></wbr></b></font></font><font face="Tahoma, sans-serif"><b>. </b></font><font face="Tahoma"><font face="Tahoma, sans-serif"><b>โดยเป็นระบบที่ใช้งานระหว่าง ผู้ประสานงาน</b></font></font><font face="Tahoma, sans-serif"><b>/</b></font><font face="Tahoma"><font face="Tahoma, sans-serif"><b>ผู้อำนวยการสำนัก</b></font></font><font face="Tahoma, sans-serif"><b>/</b></font><font face="Tahoma"><font face="Tahoma, sans-serif"><b><wbr><wbr><wbr><wbr><wbr>ผู้จัดการกองทุนฯ และได้ไปดูระบบที่ลักษณะคล้ายกั<wbr>นที่ </wbr></wbr></wbr></wbr></wbr></wbr></b></font></font><font face="Tahoma, sans-serif"><b>Nectec</b></font></p>

	</li>

	<li>

		<p align="LEFT" style="margin-bottom: 0.14in; line-height: 115%;"><font face="Tahoma"><font face="Tahoma, sans-serif"><b>จัดการอบรมเรื่องการใช้เครือข่<wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr>ายสังคม</wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></b></font></font><font face="Tahoma, sans-serif"><b>(social network)</b></font><font face="Tahoma"><font face="Tahoma, sans-serif"><b>เพื่อสนั<wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr>บการทำงานของภาคี สสส</wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></b></font></font><font face="Tahoma, sans-serif"><b>. </b></font><font face="Tahoma"><font face="Tahoma, sans-serif"><b>เมื่อวันที่ </b></font></font><font face="Tahoma, sans-serif"><b>24 </b></font><font face="Tahoma"><font face="Tahoma, sans-serif"><b>มิถุนายน โดยมีภาคีเข้าร่วมประมาณ </b></font></font><font face="Tahoma, sans-serif"><b>50 </b></font><font face="Tahoma"><font face="Tahoma, sans-serif"><b>คนโดยเนื้อหาเน้นที่การใช้เครื<wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr>อข่ายสังคม เพื่อการรณรงค์และการสื่อสารกั<wbr>บเครือข่ายในประเด็นที่ภาคี<wbr>ทำงาน</wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></b></font></font></p>

	</li>

	<li>

		<p align="LEFT" style="margin-bottom: 0.14in; line-height: 115%;"><font face="Tahoma"><font face="Tahoma, sans-serif"><b>ประชุมร่วมกั<wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr>บแผนงานการตรวจสอบภาคสังคมเพื่<wbr>อนำระบบ </wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></b></font></font><font face="Tahoma, sans-serif"><b>SMS </b></font><font face="Tahoma"><font face="Tahoma, sans-serif"><b>ไปทดลองใช้งานโดยวางแผนทดลองใช้<wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr>ในการเลือกตั้งซ่อม สส</wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></b></font></font><font face="Tahoma, sans-serif"><b>. </b></font><font face="Tahoma"><font face="Tahoma, sans-serif"><b>เขตคันนายาว</b></font></font></p>

	</li>

	<li>

		<p align="LEFT" style="margin-bottom: 0.14in; line-height: 115%;"><font face="Tahoma"><font face="Tahoma, sans-serif"><b>เข้าร่วมประชุมแผนยุทธศาสตร์เด็<wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr>กและเยาวชนของ สสส</wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></b></font></font><font face="Tahoma, sans-serif"><b>. </b></font><font face="Tahoma"><font face="Tahoma, sans-serif"><b>โดยทางแผนงาน </b></font></font><font face="Tahoma, sans-serif"><b>ICT </b></font><font face="Tahoma"><font face="Tahoma, sans-serif"><b>จะเร่งพัฒนาระบบข้อมู<wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr>ลโดยเฉพาะข้อมูลโครงการด้านเด็<wbr>กเยาวชนในรูปแบบ </wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></b></font></font><font face="Tahoma, sans-serif"><b><a href="http://base.thaihealth.or.th/" target="_blank">base.thaihealth.or.th</a> </b></font><font face="Tahoma"><font face="Tahoma, sans-serif"><b>เพื่อให้<wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr>คณะทำงานสามารถวางแผนการทำงาน และการ </wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></b></font></font><font face="Tahoma, sans-serif"><b>Visualization </b></font><font face="Tahoma"><font face="Tahoma, sans-serif"><b>ข้อมูลปัญหาด้านเด็กที่น่<wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr>าสนใจเช่น วัยรุ่นตั้งครรถ์</wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></b></font></font></p>

	</li>

	<li>

		<p align="LEFT" style="margin-bottom: 0.14in; line-height: 115%;"><font face="Tahoma"><font face="Tahoma, sans-serif"><b>เดินทางไปประชุมร่วมกับที่เฝ้<wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr>าระวังโรคระบาดจังหวัดมุ<wbr>กดาหารเพื่อ พัฒนาระบบรายงานโรคระบาดผ่าน </wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></b></font></font><font face="Tahoma, sans-serif"><b>SMS </b></font><font face="Tahoma"><font face="Tahoma, sans-serif"><b>และเชื่อมต่อตรงกับระบบข้อมู<wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr><wbr>ลโรคระบาดของ สสจ</wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></b></font></font><font face="Tahoma, sans-serif"><b>.</b></font><font face="Tahoma"><font face="Tahoma, sans-serif"><b>มุกดาหาร เมื่อวันที่ </b></font></font><font face="Tahoma, sans-serif"><b>6-7 </b></font><font face="Tahoma"><font face="Tahoma, sans-serif"><b>ก</b></font></font><font face="Tahoma, sans-serif"><b>.</b></font><font face="Tahoma"><font face="Tahoma, sans-serif"><b>ค</b></font></font><font face="Tahoma, sans-serif"><b>. </b></font></p>

	</li>

	<li>

		<p align="LEFT" style="margin-bottom: 0.14in; line-height: 115%;"><font face="Tahoma"><font face="Tahoma, sans-serif"><b>พัฒนาโครงการอินเทอร์เน็ตทีวี โดยเสนอโครงการให้กับทางสำนัก </b></font></font><font face="Tahoma, sans-serif"><b>5 </b></font><font face="Tahoma"><font face="Tahoma, sans-serif"><b>สสส</b></font></font><font face="Tahoma, sans-serif"><b>.</b></font></p>

	</li>

</ul>

</wbr></wbr></wbr></wbr></wbr></p>

</wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></p>

', '2010-07-22 11:45:31.017245+07', 3);
INSERT INTO report_reportsubmissiontextresponse VALUES (34, '<p>งานด้านสุขภาวะออนไลน์<br />

- เปิดตัวโครงการ Idea for Thailand (<a href="http://ideas.in.th/" target="_blank">ideas.in.th</a>)ร่วมกับสำนักนายกรัฐมนตรี เมื่อวันที่ 4 ส.ค. 53เพื่อเปิดรับโครงการพัฒนาสังคม จากภาคประชาชน<br />

<br />

การสนับสนุนภาคีเครือข่าย<br />

<br />

- พัฒนา Web องค์กรให้กับ สสค.<br />

- แนะนำการใช้งานระบบ mapping พื้นที่เสี่ยงรอบโรงเรียนให้กับโครงการแผนที่สุขภาพสมาคมผู้บำเพ็ญประโยชน์</p>

<div id=":1sh">

	- ให้คำปรึกษาเรื่องเกมสร้างเสริ<wbr>มความจำและฝึกนิสัยการใช้อินเทอร์เน็<wbr>ตอย่างปลอดภัยให้กับเยาวชนให้กับแผนงานทุนอุปภัมภ์<br />

	- เดินทางไปติดตามงานเฝ้าระวั<wbr>งโรคระบาดจังหวัดมุ<wbr>กดาหารในการพั<wbr>ฒนาระบบรายงานโรคระบาดผ่าน<br />

	SMS และเชื่อมต่อตรงกับระบบข้อมู<wbr>ลโรคระบาดของ สสจ.มุกดาหาร เมื่อวันที่<br />

	</wbr></wbr></wbr></wbr></wbr></wbr></div>

<p><wbr>

<p><wbr><wbr><wbr><wbr><wbr><wbr>

<div>

	9-10 ส.ค.<br />

	- เริ่มดำเนินการโครงการอินเทอร์<wbr>เน็ตทีวี ร่วมกับสำนัก 5 สสส.</wbr></div>

</wbr></wbr></wbr></wbr></wbr></wbr></p>

</wbr></p>

', '2010-08-31 11:11:44.172403+07', 3);


--
-- PostgreSQL database dump complete
--

